/**
 * content.js
 * 
 * Versão: 1.0.1 (Fix: Card Expansion Delay & Scroll)
 * - Ajuste de CSS: Cards agora mostram "..." e só expandem após 0.6s de hover.
 * - Scroll: Reforçado comportamento de scroll na lista de projetos.
 */

// -----------------------------------------------------------------------------
// CONSTANTES & ESTADO GLOBAL
// -----------------------------------------------------------------------------

const SYSTEM_INSTRUCTION_TEMPLATE = `
Você é um filtro de projetos experiente e tech recruiter.
Sua missão é analisar uma lista de projetos e selecionar apenas os melhores baseados no PERFIL DO USUÁRIO fornecido.

REGRAS DE SAÍDA (IMPORTANTE):
1. Retorne APENAS um JSON Array de objetos.
2. O formato deve ser estritamente: [{"id": "string", "summary": "string"}].
3. No campo "summary", escreva um resumo curto (max 30 palavras) vendendo o projeto para o candidato.
4. Use formatação Markdown no resumo (negrito **texto** para tecnologias/skills principais).
5. Não inclua explicações, intro ou markdown code blocks (\`\`\`json). Apenas o JSON cru.

PERFIL DO USUÁRIO PARA FILTRAGEM:
`;

const PROPOSAL_SYSTEM_INSTRUCTION = `
🔥 PROMPT DEFINITIVO — PROPOSTAS QUE FECHAM PROJETO
Você é uma IA especialista em fechamento de projetos de tecnologia, com foco em conversão, autoridade, clareza estratégica e persuasão profissional.
Seu papel não é listar tecnologias, mas convencer o cliente de que a solução será entregue com excelência, previsibilidade e impacto real no negócio.

📌 PERFIL DO PROFISSIONAL
O profissional que você representa é Patrick Gomes Siqueira, Desenvolvedor Full Stack Sênior, com mais de 7 anos de experiência.
Patrick é Top Freelancer Plus no 99Freelas, está entre os Top 60–100 profissionais da plataforma, possui avaliação 5 estrelas e histórico consistente de projetos entregues com alto nível técnico, organização e responsabilidade.
Ele não atua como executor de tarefas, mas como parceiro técnico estratégico, responsável por decisões que impactam diretamente o resultado do projeto e o sucesso do cliente.

  🎯 OBJETIVO PRINCIPAL
  Gerar uma proposta profissional, formal, humana e altamente persuasiva. Retorne APENAS um JSON válido.

  📐 REGRAS OBRIGATÓRIAS DO TEXTO
  ✔ LIMITE DE TAMANHO: A proposta deve ter no MÁXIMO 2.500 caracteres. Nunca ultrapasse este limite.
  ✔ 100% Formal — Sem informalidades, emojis ou linguagem coloquial
  ✔ 100% Confiante — Proibido: "posso", "consigo", "tentarei". Usar: "realizarei", "implementarei", "entregarei"
  ✔ Humano, direto e profissional — Texto fluido, sem frases genéricas
  ✔ Sem redundâncias — Nunca repetir o texto do projeto
  ✔ Texto em funil — Cada parágrafo deve aumentar a confiança

  🧩 ESTRUTURA OBRIGATÓRIA (Dentro do campo "message"):
  1. SAUDAÇÃO INICIAL — Nome, senioridade, interesse estratégico no projeto
  2. ENTENDIMENTO DO PROJETO — Problema real, impacto de negócio (sem copiar o enunciado)
  3. SOLUÇÃO — Como o problema será resolvido, método e domínio
  4. ORÇAMENTO — Apresentado com custo-benefício
  5. PRAZO — Apresentado como realista e atrativo
  6. FINALIZAÇÃO (EXATA): "Fico na expectativa de seu pronunciamento e me encontro às ordens para maiores esclarecimentos.\\nSaudações,\\nPatrick Siqueira"

  REGRAS DE FORMATAÇÃO (ESTRITO):
  1. Retorne APENAS um JSON válido.
  2. Formato JSON:
  {
    "message": "Texto completo e persuasivo aqui...",
    "price": 0,
    "duration": 0
  }
  `;

// Detecta qual site está sendo acessado
const CURRENT_SITE = window.location.hostname.includes('freelancer.com')
    ? 'freelancer'
    : window.location.hostname.includes('workana.com')
        ? 'workana'
        : '99freelas';

const STATE = {
    isSidebarOpen: false,
    isHoveringEdge: false,
    scrapedProjects: [],
    lastAutoRunUrl: '', // Para evitar loop no modo automático
    user: null, // Usuário logado na extensão
    quickButtons: [], // Botões de disparo rápido (mensagens) — por usuário
    lastQuickId: null, // Último botão rápido usado (para o atalho global)
    radarAutoSubmit: false, // Flag: aba de bid (worker) foi aberta pelo Radar
    radarNextSent: false,   // Worker já pediu o próximo da fila?
    radarTimer: null,       // setInterval (fallback de recoleta)
    radarObserver: null,    // MutationObserver do contador do header
    radarQueuedUrls: null,  // Set de URLs já enfileiradas nesta sessão (dedup)
    msgObserver: null,      // MutationObserver do contador de mensagens
    msgTimer: null,         // setInterval (reaviso de 5 min)
    radarCollecting: false, // trava de concorrência da varredura do Radar
    radarVisHooked: false,  // já registrou o listener de visibilitychange do Radar?
    settings: {
        apiKey: '',  // Gemini API Key
        groqApiKey: '', // Groq API Key
        groqModel: 'llama-3.3-70b-versatile', // Modelo Groq padrão
        openaiKeys: [],    // OpenAI API Keys (cluster)
        claudeKeys: [],    // Anthropic Claude API Keys (cluster)
        openaiModel: 'gpt-4o-mini',     // Modelo OpenAI padrão
        claudeModel: 'claude-haiku-4-5', // Modelo Claude padrão
        preferredProvider: 'openai',     // Provider preferido
        apiUrl: 'https://geral-auto-proposal-api.r954jc.easypanel.host', // Sua API em produção
        useBackend: true,               // Ativado por padrão agora que está no ar
        activePlatform: '99freelas', // '99freelas', 'freelancer' ou 'workana'
        // Prompts para 99freelas
        userProfile_99freelas: 'Sou um Desenvolvedor Fullstack Sênior (Node.js, React, Python). Busco projetos de desenvolvimento web, automação e APIs.',
        proposalPrompt_99freelas: 'Escreva uma proposta curta, direta e persuasiva. Foque em resolver o problema do cliente. Use tom profissional mas próximo.',
        // Prompts para Freelancer.com
        userProfile_freelancer: 'I am a Senior Fullstack Developer (Node.js, React, Python). Looking for web development, automation and API projects.',
        proposalPrompt_freelancer: 'Write a short, direct and persuasive proposal. Focus on solving the client problem. Use professional but friendly tone.',
        // Prompts para Workana
        userProfile_workana: 'Sou um Desenvolvedor Fullstack Sênior (Node.js, React, Python). Busco projetos de desenvolvimento web, automação e APIs.',
        proposalPrompt_workana: 'Escreva uma proposta curta, direta e persuasiva. Foque em resolver o problema do cliente. Use tom profissional mas próximo.',
        // Configurações gerais (mantidas para compatibilidade)
        userProfile: '',
        proposalPrompt: '',
        autoProposalMode: false,
        shortcuts: {
            analyze: { modifier: 'Shift', key: 'P' },
            generate: { modifier: 'Shift', key: 'G' },
            quickSend: { modifier: 'Shift', key: 'M' }
        }
    }
};

// -----------------------------------------------------------------------------
// 1. INJEÇÃO DE ESTILOS (CSS)
// -----------------------------------------------------------------------------

function injectStyles() {
    if (document.getElementById('ap-styles')) return;

    const style = document.createElement('style');
    style.id = 'ap-styles';
    style.textContent = `
        /* --- FONTES & RESET --- */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

        :root {
            /* --- SUPERFÍCIES (macOS Vibrancy) --- */
            --ap-glass-bg: rgba(38, 38, 42, 0.72);
            --ap-glass-bg-elevated: rgba(52, 52, 58, 0.82);
            --ap-glass-border: rgba(255, 255, 255, 0.08);
            --ap-glass-border-highlight: rgba(255, 255, 255, 0.14);
            
            /* --- TIPOGRAFIA --- */
            --ap-text-primary: rgba(255, 255, 255, 0.98);
            --ap-text-secondary: rgba(255, 255, 255, 0.55);
            --ap-text-tertiary: rgba(255, 255, 255, 0.35);
            
            /* --- CORES DE ACENTO (Apple Blue) --- */
            --ap-accent-color: #0A84FF;
            --ap-accent-hover: #409CFF;
            --ap-accent-gradient: linear-gradient(180deg, #3B9EFF 0%, #0A84FF 100%);
            
            /* --- SEMÂNTICAS --- */
            --ap-success: #30D158;
            --ap-warning: #FFD60A;
            --ap-danger: #FF453A;
            
            /* --- SOMBRAS (Elevation) --- */
            --ap-shadow-sm: 0 2px 8px rgba(0,0,0,0.2);
            --ap-shadow-md: 0 8px 24px rgba(0,0,0,0.35);
            --ap-shadow-lg: 0 24px 56px rgba(0,0,0,0.55);
            --ap-shadow-glow: 0 0 20px rgba(10, 132, 255, 0.3);
            
            /* --- ESPAÇAMENTOS --- */
            --ap-spacing-xs: 4px;
            --ap-spacing-sm: 8px;
            --ap-spacing-md: 16px;
            --ap-spacing-lg: 24px;
            --ap-spacing-xl: 32px;
            
            /* --- RAIOS DE BORDA --- */
            --ap-radius-sm: 6px;
            --ap-radius-md: 10px;
            --ap-radius-lg: 14px;
            --ap-radius-xl: 18px;
            
            /* --- ANIMAÇÕES --- */
            --ap-ease: cubic-bezier(0.25, 0.46, 0.45, 0.94);
            --ap-ease-spring: cubic-bezier(0.175, 0.885, 0.32, 1.275);
            --ap-ease-out: cubic-bezier(0.16, 1, 0.3, 1);
            --ap-duration-fast: 150ms;
            --ap-duration-normal: 250ms;
            --ap-duration-slow: 400ms;
            
            /* --- FONTE --- */
            --ap-font: -apple-system, BlinkMacSystemFont, "SF Pro Display", "Inter", "Segoe UI", sans-serif;
            --ap-font-mono: "SF Mono", "Fira Code", "Consolas", monospace;
        }

        /* --- LOGIN SCREEN --- */
        .ap-login-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            padding: var(--ap-spacing-xl);
            text-align: center;
            animation: ap-fadeInUp 0.6s ease-out;
        }

        @keyframes ap-fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes ap-pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        @keyframes ap-checkmark {
            0% { transform: scale(0) rotate(-45deg); opacity: 0; }
            50% { transform: scale(1.2) rotate(-45deg); opacity: 1; }
            100% { transform: scale(1) rotate(-45deg); opacity: 1; }
        }

        .ap-login-icon {
            width: 64px;
            height: 64px;
            border-radius: 20px;
            background: linear-gradient(135deg, rgba(10,132,255,0.2), rgba(94,92,230,0.2));
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            border: 1px solid rgba(10,132,255,0.3);
        }

        .ap-login-logo {
            font-size: 26px;
            font-weight: 800;
            margin-bottom: 6px;
            background: var(--ap-accent-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .ap-login-subtitle {
            color: var(--ap-text-secondary);
            font-size: 13px;
            margin-bottom: 32px;
            line-height: 1.5;
        }

        .ap-login-form {
            width: 100%;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .ap-login-input-group {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap: 6px;
        }

        .ap-login-label {
            font-size: 11px;
            font-weight: 600;
            color: var(--ap-text-secondary);
            margin-left: 4px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .ap-login-input {
            width: 100%;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--ap-glass-border);
            border-radius: var(--ap-radius-md);
            padding: 14px 16px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
            box-sizing: border-box;
        }

        .ap-login-input:focus {
            outline: none;
            border-color: var(--ap-accent-color);
            background: rgba(255,255,255,0.08);
            box-shadow: 0 0 0 4px rgba(10, 132, 255, 0.15);
        }

        .ap-login-button {
            margin-top: 8px;
            background: var(--ap-accent-gradient);
            border: none;
            border-radius: var(--ap-radius-md);
            padding: 14px;
            color: white;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(10, 132, 255, 0.3);
            letter-spacing: 0.02em;
        }

        .ap-login-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(10, 132, 255, 0.4);
        }

        .ap-login-button:active {
            transform: translateY(0);
        }

        .ap-login-button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .ap-login-error {
            color: var(--ap-danger);
            font-size: 12px;
            margin-top: 4px;
            display: none;
            background: rgba(255, 69, 58, 0.1);
            padding: 10px;
            border-radius: var(--ap-radius-md);
            border: 1px solid rgba(255, 69, 58, 0.2);
        }

        /* Success Screen */
        .ap-success-screen {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            animation: ap-fadeInUp 0.5s ease-out;
        }

        .ap-success-circle {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #34c759, #30d158);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 24px;
            box-shadow: 0 8px 30px rgba(52, 199, 89, 0.3);
            animation: ap-pulse 1.5s ease-in-out infinite;
        }

        .ap-success-check {
            width: 32px;
            height: 16px;
            border-left: 3px solid white;
            border-bottom: 3px solid white;
            animation: ap-checkmark 0.5s ease-out 0.2s both;
        }

        .ap-success-title {
            font-size: 20px;
            font-weight: 700;
            color: white;
            margin-bottom: 6px;
        }

        .ap-success-sub {
            color: var(--ap-text-secondary);
            font-size: 13px;
        }

        .ap-logout-btn {
            background: transparent;
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: var(--ap-radius-md);
            padding: 8px 12px;
            color: var(--ap-text-secondary);
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .ap-logout-btn:hover {
            background: rgba(255, 69, 58, 0.1);
            color: var(--ap-danger);
            border-color: rgba(255, 69, 58, 0.2);
        }

        /* --- USER PROFILE HEADER --- */
        .ap-user-header {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .ap-user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 10px;
            object-fit: cover;
            border: 2px solid rgba(10, 132, 255, 0.3);
            flex-shrink: 0;
        }

        .ap-user-avatar-fallback {
            width: 32px;
            height: 32px;
            border-radius: 10px;
            background: linear-gradient(135deg, #5e5ce6, #0a84ff);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 12px;
            color: white;
            flex-shrink: 0;
        }

        /* --- PROFILE SCREEN --- */
        .ap-profile-screen {
            display: flex;
            flex-direction: column;
            height: 100%;
            padding: var(--ap-spacing-lg);
            animation: ap-fadeInUp 0.4s ease-out;
        }

        .ap-profile-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 24px;
        }

        .ap-profile-back {
            background: rgba(255,255,255,0.06);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 10px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            color: white;
            transition: all 0.2s;
        }

        .ap-profile-back:hover {
            background: rgba(255,255,255,0.1);
        }

        .ap-profile-avatar {
            width: 72px;
            height: 72px;
            border-radius: 20px;
            object-fit: cover;
            border: 2px solid rgba(10, 132, 255, 0.4);
            margin: 0 auto 16px;
            display: block;
        }

        .ap-profile-avatar-fallback {
            width: 72px;
            height: 72px;
            border-radius: 20px;
            background: linear-gradient(135deg, #5e5ce6, #0a84ff);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 24px;
            color: white;
            margin: 0 auto 16px;
        }

        .ap-profile-name {
            text-align: center;
            font-size: 18px;
            font-weight: 700;
            color: white;
            margin-bottom: 4px;
        }

        .ap-profile-email {
            text-align: center;
            font-size: 12px;
            color: var(--ap-text-secondary);
            margin-bottom: 28px;
        }

        .ap-profile-section-title {
            font-size: 11px;
            font-weight: 600;
            color: var(--ap-text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 12px;
        }

        .ap-profile-form {
            display: flex;
            flex-direction: column;
            gap: 14px;
        }

        .ap-profile-save {
            margin-top: 8px;
            background: var(--ap-accent-gradient);
            border: none;
            border-radius: var(--ap-radius-md);
            padding: 12px;
            color: white;
            font-weight: 700;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(10, 132, 255, 0.3);
        }

        .ap-profile-save:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(10, 132, 255, 0.4);
        }

        .ap-profile-save:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .ap-profile-msg {
            text-align: center;
            font-size: 12px;
            padding: 10px;
            border-radius: var(--ap-radius-md);
            display: none;
        }

        .ap-profile-msg.success {
            display: block;
            color: #34c759;
            background: rgba(52, 199, 89, 0.1);
            border: 1px solid rgba(52, 199, 89, 0.2);
        }

        .ap-profile-msg.error {
            display: block;
            color: var(--ap-danger);
            background: rgba(255, 69, 58, 0.1);
            border: 1px solid rgba(255, 69, 58, 0.2);
        }

        /* --- SIDEBAR CONTAINER (macOS Vibrancy) --- */
        #ap-sidebar {
            position: fixed;
            top: 0;
            right: -420px;
            width: 420px;
            height: 100vh;
            background: linear-gradient(180deg, rgba(44, 44, 50, 0.85) 0%, rgba(30, 30, 36, 0.92) 100%);
            backdrop-filter: blur(80px) saturate(200%);
            -webkit-backdrop-filter: blur(80px) saturate(200%);
            border-left: 1px solid rgba(255,255,255,0.1);
            box-shadow: 
                -1px 0 0 rgba(255,255,255,0.05) inset,
                -20px 0 60px rgba(0,0,0,0.5);
            z-index: 2147483647;
            transition: right 0.5s var(--ap-ease-out);
            display: flex;
            flex-direction: column;
            font-family: var(--ap-font);
            color: var(--ap-text-primary);
        }

        #ap-sidebar.open { right: 0; }

        /* --- HANDLE (Floating Pill) --- */
        #ap-sidebar-handle {
            position: absolute;
            left: -18px;
            top: 50%;
            transform: translateY(-50%) scale(0.9);
            width: 36px;
            height: 72px;
            background: linear-gradient(180deg, rgba(60,60,68,0.9) 0%, rgba(45,45,52,0.95) 100%);
            backdrop-filter: blur(40px) saturate(180%);
            -webkit-backdrop-filter: blur(40px) saturate(180%);
            border: 1px solid rgba(255,255,255,0.12);
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            opacity: 0;
            transition: all 0.4s var(--ap-ease-spring);
            pointer-events: none;
            box-shadow: 
                0 0 0 0.5px rgba(255,255,255,0.08) inset,
                0 8px 32px rgba(0,0,0,0.4);
        }

        #ap-sidebar-handle svg {
            opacity: 0.6;
            transition: opacity 0.2s, transform 0.3s var(--ap-ease);
            filter: drop-shadow(0 1px 2px rgba(0,0,0,0.3));
        }

        #ap-sidebar-handle.visible {
            opacity: 1;
            pointer-events: all;
            transform: translateY(-50%) translateX(-6px) scale(1);
        }

        #ap-sidebar-handle:hover {
            background: linear-gradient(180deg, rgba(70,70,80,0.95) 0%, rgba(50,50,60,0.98) 100%);
            transform: translateY(-50%) translateX(-10px) scale(1.08);
            border-color: var(--ap-accent-color);
            box-shadow: 
                0 0 0 0.5px rgba(255,255,255,0.12) inset,
                0 0 24px rgba(10, 132, 255, 0.25),
                0 8px 32px rgba(0,0,0,0.5);
        }

        #ap-sidebar-handle:hover svg {
            opacity: 1;
            transform: translateX(-2px);
        }

        /* --- HEADER (macOS Window Title Bar) --- */
        .ap-header {
            padding: 18px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(255,255,255,0.06);
            background: linear-gradient(180deg, rgba(255,255,255,0.04) 0%, transparent 100%);
            flex-shrink: 0;
            position: relative;
        }

        .ap-header::after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 20px;
            right: 20px;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.08), transparent);
        }

        .ap-header h2 {
            margin: 0;
            font-size: 14px;
            font-weight: 600;
            letter-spacing: -0.2px;
            color: var(--ap-text-primary);
            text-shadow: 0 1px 2px rgba(0,0,0,0.3);
        }

        .ap-icon-btn {
            background: rgba(255,255,255,0.06);
            border: 1px solid rgba(255,255,255,0.08);
            color: var(--ap-text-secondary);
            cursor: pointer;
            padding: 7px;
            border-radius: 8px;
            transition: all var(--ap-duration-fast) var(--ap-ease);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .ap-icon-btn:hover {
            background: rgba(255,255,255,0.12);
            border-color: rgba(255,255,255,0.15);
            color: var(--ap-text-primary);
        }

        .ap-icon-btn:active {
            transform: scale(0.94);
            background: rgba(255,255,255,0.08);
        }

        /* --- CONTENT AREA (SCROLLABLE) --- */
        .ap-content {
            flex: 1;
            overflow-y: auto;
            padding: 16px 16px 20px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            min-height: 0;
        }

        .ap-content p {
            color: #fff;
        }
        
        /* Custom Scrollbar (macOS Style) */
        .ap-content::-webkit-scrollbar { width: 10px; }
        .ap-content::-webkit-scrollbar-track { background: transparent; margin: 8px 0; }
        .ap-content::-webkit-scrollbar-thumb { 
            background: rgba(255,255,255,0.12); 
            border-radius: 100px;
            border: 3px solid transparent;
            background-clip: padding-box;
        }
        .ap-content::-webkit-scrollbar-thumb:hover { 
            background: rgba(255,255,255,0.2); 
            background-clip: padding-box;
        }

        .ap-empty-state {
            margin-top: 80px;
            text-align: center;
            color: var(--ap-text-tertiary);
            font-size: 13px;
            line-height: 1.7;
            padding: 0 40px;
        }

        .ap-empty-state svg {
            margin-bottom: 20px;
            opacity: 0.3;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
        }

        /* --- PROJECT CARDS (macOS List Item Style) --- */
        .ap-card {
            background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 12px;
            padding: 14px 16px 14px 18px;
            cursor: pointer;
            transition: all 0.25s var(--ap-ease);
            position: relative;
            overflow: hidden;
            flex-shrink: 0;
        }

        /* Accent indicator bar (left side) */
        .ap-card::before {
            content: '';
            position: absolute;
            top: 12px;
            bottom: 12px;
            left: 0;
            width: 3px;
            background: var(--ap-accent-color);
            border-radius: 0 3px 3px 0;
            opacity: 0;
            transform: scaleY(0.5);
            transition: all 0.25s var(--ap-ease-spring);
        }

        /* Subtle top highlight */
        .ap-card::after {
            content: '';
            position: absolute;
            top: 0;
            left: 20px;
            right: 20px;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.06), transparent);
        }

        .ap-card:hover {
            background: linear-gradient(135deg, rgba(255,255,255,0.09) 0%, rgba(255,255,255,0.04) 100%);
            border-color: rgba(255,255,255,0.12);
            transform: translateX(-4px);
            box-shadow: 
                4px 4px 20px rgba(0,0,0,0.2),
                0 0 0 1px rgba(255,255,255,0.05) inset;
        }

        .ap-card:hover::before {
            opacity: 1;
            transform: scaleY(1);
        }

        .ap-card:active {
            transform: translateX(-2px) scale(0.995);
            transition-duration: 0.1s;
        }

        .ap-hidden { display: none !important; }

        /* --- ABAS (Settings) --- */
        .ap-tabs {
            display: flex;
            gap: 6px;
            background: rgba(0,0,0,0.25);
            padding: 4px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.06);
        }
        .ap-tab-btn {
            flex: 1;
            padding: 9px 12px;
            border: none;
            border-radius: 9px;
            background: transparent;
            color: rgba(255,255,255,0.55);
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.15s ease;
        }
        .ap-tab-btn:hover { color: rgba(255,255,255,0.85); }
        .ap-tab-btn.active {
            background: rgba(255,255,255,0.1);
            color: #fff;
            box-shadow: 0 1px 3px rgba(0,0,0,0.25);
        }
        .ap-tab-panel {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        /* --- WHATSAPP --- */
        .ap-wa-status {
            font-size: 12px;
            font-weight: 600;
            padding: 8px 12px;
            border-radius: 9px;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.08);
            color: var(--ap-text-secondary);
        }
        .ap-wa-status.connected { color: #30D158; border-color: rgba(48,209,88,0.3); background: rgba(48,209,88,0.08); }
        .ap-wa-status.disconnected { color: #FF6961; border-color: rgba(255,105,97,0.3); background: rgba(255,105,97,0.08); }
        .ap-wa-status.connecting { color: #FFD426; border-color: rgba(255,212,38,0.3); background: rgba(255,212,38,0.08); }
        .ap-wa-qr {
            text-align: center;
            margin-top: 12px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
        }
        .ap-wa-qr img {
            width: 240px;
            height: 240px;
            border-radius: 12px;
            background: #fff;
            padding: 8px;
        }
        .ap-wa-qr small { color: var(--ap-text-tertiary); font-size: 10px; max-width: 260px; }

        .ap-card-title {
            font-size: 13px;
            font-weight: 600;
            color: #5CB8FF;
            margin-bottom: 6px;
            line-height: 1.4;
            letter-spacing: -0.1px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        /* Optional: Add arrow icon on hover */
        .ap-card-title::after {
            content: '→';
            font-size: 12px;
            opacity: 0;
            transform: translateX(-8px);
            transition: all 0.25s var(--ap-ease);
            color: var(--ap-accent-color);
        }

        .ap-card:hover .ap-card-title::after {
            opacity: 0.7;
            transform: translateX(0);
        }

        /* --- EXPANDABLE DESCRIPTION --- */
        .ap-card-desc {
            font-size: 12px;
            color: rgba(255,255,255,0.6);
            line-height: 1.6;
            
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            
            max-height: 42px;
            transition: max-height 0.5s var(--ap-ease), color 0.3s;
        }

        .ap-card:hover .ap-card-desc {
            -webkit-line-clamp: unset;
            max-height: 600px;
            color: rgba(255,255,255,0.85);
            transition-delay: 0.5s;
        }
        
        .ap-card-desc strong, .ap-card-desc b { 
            color: #fff; 
            font-weight: 600; 
        }
        .ap-card-desc em, .ap-card-desc i { 
            color: var(--ap-text-secondary); 
            font-style: italic; 
        }
        .ap-card-desc code { 
            background: rgba(255,255,255,0.1); 
            padding: 1px 5px; 
            border-radius: 4px; 
            font-family: var(--ap-font-mono); 
            font-size: 0.85em; 
        }
        .ap-card-desc ul { padding-left: 14px; margin: 4px 0; }

        /* --- FOOTER (Subtle Branding) --- */
        .ap-footer {
            padding: 12px 20px;
            border-top: 1px solid rgba(255,255,255,0.05);
            background: linear-gradient(180deg, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.2) 100%);
            text-align: center;
            font-size: 10px;
            color: rgba(18, 183, 224, 0.7);
            flex-shrink: 0;
            letter-spacing: 0.8px;
            text-transform: uppercase;
            font-weight: 500;
        }

        /* --- PRIMARY BUTTON (macOS Style) --- */
        .ap-btn-primary {
            width: 100%;
            padding: 12px 20px;
            background: var(--ap-accent-gradient);
            color: white;
            border: none;
            border-radius: var(--ap-radius-md);
            font-size: 14px;
            font-weight: 600;
            letter-spacing: -0.2px;
            cursor: pointer;
            transition: all var(--ap-duration-fast) var(--ap-ease);
            box-shadow: 
                0 1px 0 rgba(255,255,255,0.1) inset,
                0 -1px 0 rgba(0,0,0,0.1) inset,
                var(--ap-shadow-sm);
        }

        .ap-btn-primary:hover {
            filter: brightness(1.1);
            box-shadow: 
                0 1px 0 rgba(255,255,255,0.15) inset,
                0 -1px 0 rgba(0,0,0,0.1) inset,
                var(--ap-shadow-glow);
        }

        .ap-btn-primary:active {
            transform: scale(0.98);
            filter: brightness(0.95);
        }

        /* --- MODAL OVERLAY (macOS Backdrop) --- */
        #ap-modal-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            z-index: 2147483648;
            display: none;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.25s var(--ap-ease);
        }

        #ap-modal-overlay.show { display: flex; opacity: 1; }

        /* --- MODAL (macOS Window) --- */
        .ap-modal {
            background: var(--ap-glass-bg);
            backdrop-filter: blur(72px) saturate(190%);
            -webkit-backdrop-filter: blur(72px) saturate(190%);
            width: 540px !important; /* Força a largura fixa */
            max-width: 90vw;
            max-height: 85vh;
            border-radius: var(--ap-radius-xl);
            border: 1px solid var(--ap-glass-border-highlight);
            box-shadow: 
                0 0 0 0.5px rgba(255,255,255,0.1) inset,
                var(--ap-shadow-lg);
            display: flex !important;
            flex-direction: column !important;
            color: var(--ap-text-primary);
            transform: scale(0.96) translateY(10px);
            transition: transform 0.3s var(--ap-ease-spring);
            overflow: hidden;
            position: relative;
        }
        
        #ap-modal-overlay.show .ap-modal { 
            transform: scale(1) translateY(0); 
        }

        /* --- MODAL HEADER (macOS Title Bar) --- */
        .ap-modal-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            padding: 16px 20px;
            background: linear-gradient(180deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0) 100%);
            border-bottom: 1px solid var(--ap-glass-border);
            flex-shrink: 0;
        }

        .ap-modal-header h3 { 
            margin: 0; 
            font-size: 14px; 
            font-weight: 600;
            letter-spacing: -0.2px;
            color: #fff;
        }

        /* Close Button (macOS Red Dot) */
        .ap-close-btn {
            width: 13px;
            height: 13px;
            border-radius: 50%;
            background: var(--ap-danger);
            border: none;
            cursor: pointer;
            transition: all var(--ap-duration-fast);
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .ap-close-btn::before,
        .ap-close-btn::after {
            content: '';
            position: absolute;
            width: 7px;
            height: 1.5px;
            background: rgba(0,0,0,0.5);
            opacity: 0;
            transition: opacity var(--ap-duration-fast);
        }

        .ap-close-btn::before { transform: rotate(45deg); }
        .ap-close-btn::after { transform: rotate(-45deg); }

        .ap-close-btn:hover::before,
        .ap-close-btn:hover::after {
            opacity: 1;
        }

        .ap-close-btn:active {
            transform: scale(0.9);
        }

        /* --- MODAL BODY (Scrollable) --- */
        .ap-modal-body {
            flex: 1 !important;
            overflow-y: auto !important;
            overflow-x: hidden !important;
            display: flex !important;
            flex-direction: column !important;
            gap: 20px !important;
            padding: 24px !important;
            min-height: 0; /* Essencial para scroll em flexbox */
        }

        .ap-modal-body::-webkit-scrollbar { width: 8px; }
        .ap-modal-body::-webkit-scrollbar-track { background: transparent; }
        .ap-modal-body::-webkit-scrollbar-thumb { 
            background: rgba(255,255,255,0.12); 
            border-radius: 100px;
            border: 2px solid transparent;
            background-clip: padding-box;
        }

        /* --- INPUT GROUPS (macOS Style) --- */
        .ap-input-group { 
            display: flex; 
            flex-direction: column; 
            gap: 8px; 
        }

        .ap-input-group label { 
            font-size: 12px; 
            text-transform: uppercase; 
            color: var(--ap-text-secondary); 
            font-weight: 600; 
            letter-spacing: 0.5px;
        }

        .ap-input, .ap-textarea {
            background: rgba(0, 0, 0, 0.25);
            border: 1px solid var(--ap-glass-border);
            border-radius: var(--ap-radius-md);
            padding: 12px 14px;
            color: var(--ap-text-primary) !important;
            font-family: var(--ap-font);
            font-size: 13px;
            line-height: 1.5;
            transition: all var(--ap-duration-fast) var(--ap-ease);
        }

        .ap-input::placeholder, .ap-textarea::placeholder {
            color: var(--ap-text-tertiary);
        }
        
        .ap-input:hover, .ap-textarea:hover {
            border-color: var(--ap-glass-border-highlight);
        }
        
        .ap-input:focus, .ap-textarea:focus {
            background: rgba(0, 0, 0, 0.35) !important;
            border-color: var(--ap-accent-color) !important;
            outline: none;
            box-shadow: 0 0 0 3px rgba(10, 132, 255, 0.2);
        }

        .ap-textarea {
            display: block !important;
            width: 100% !important;
            min-height: 100px !important;
            resize: vertical;
            box-sizing: border-box;
        }

        /* --- SELECT (macOS Style) --- */
        .ap-select {
            background: rgba(0, 0, 0, 0.25);
            border: 1px solid var(--ap-glass-border);
            border-radius: var(--ap-radius-md);
            padding: 12px 14px;
            color: var(--ap-text-primary) !important;
            font-family: var(--ap-font);
            font-size: 13px;
            line-height: 1.5;
            transition: all var(--ap-duration-fast) var(--ap-ease);
            cursor: pointer;
            appearance: none;
            -webkit-appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='rgba(255,255,255,0.5)' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 14px center;
            padding-right: 40px;
        }

        .ap-select:hover {
            border-color: var(--ap-glass-border-highlight);
        }

        .ap-select:focus {
            background-color: rgba(0, 0, 0, 0.35);
            border-color: var(--ap-accent-color) !important;
            outline: none;
            box-shadow: 0 0 0 3px rgba(10, 132, 255, 0.2);
        }

        .ap-select option {
            background: #2a2a2e;
            color: #fff;
            padding: 8px;
        }

        /* --- SECTION DIVIDER --- */
        .ap-section-divider {
            height: 1px;
            background: var(--ap-glass-border);
            margin: 4px 0;
        }

        /* --- SHORTCUT BUTTONS (Keyboard Style) --- */
        .ap-shortcut-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
        }

        .ap-shortcut-row span { 
            font-size: 13px; 
            color: var(--ap-text-secondary);
        }

        .ap-shortcut-btn {
            background: linear-gradient(180deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%);
            border: 1px solid var(--ap-glass-border-highlight);
            border-bottom-width: 2px;
            color: var(--ap-text-primary);
            padding: 6px 14px;
            border-radius: var(--ap-radius-sm);
            cursor: pointer;
            font-family: var(--ap-font-mono);
            font-size: 11px;
            font-weight: 500;
            letter-spacing: 0.5px;
            transition: all var(--ap-duration-fast) var(--ap-ease);
            text-align: center;
            min-width: 90px;
            box-shadow: 
                0 1px 0 rgba(255,255,255,0.05) inset,
                0 2px 4px rgba(0,0,0,0.15);
        }

        .ap-shortcut-btn:hover { 
            background: linear-gradient(180deg, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.08) 100%);
            border-color: var(--ap-text-secondary);
        }

        .ap-shortcut-btn:active {
            transform: translateY(1px);
            box-shadow: none;
        }

        .ap-shortcut-btn.recording {
            background: var(--ap-accent-gradient);
            border-color: var(--ap-accent-color);
            animation: pulse 1s infinite;
        }

        /* --- TOGGLE SWITCH (iOS 17 Style) --- */
        .ap-toggle {
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            padding: 8px 0;
        }

        .ap-toggle input { display: none; }

        .ap-toggle-track {
            width: 51px; 
            height: 31px;
            background: rgba(120, 120, 128, 0.32);
            border-radius: 16px;
            position: relative;
            transition: background 0.3s var(--ap-ease);
            flex-shrink: 0;
        }

        .ap-toggle-thumb {
            width: 27px; 
            height: 27px;
            background: #fff;
            border-radius: 50%;
            position: absolute;
            top: 2px; 
            left: 2px;
            transition: transform 0.3s var(--ap-ease-spring);
            box-shadow: 
                0 3px 8px rgba(0,0,0,0.15),
                0 3px 1px rgba(0,0,0,0.06);
        }

        .ap-toggle input:checked + .ap-toggle-track { 
            background: var(--ap-success); 
        }

        .ap-toggle input:checked + .ap-toggle-track .ap-toggle-thumb { 
            transform: translateX(20px); 
        }

        .ap-toggle-label {
            font-size: 13px;
            color: var(--ap-text-primary);
            font-weight: 400;
        }

        /* --- MODAL FOOTER --- */
        .ap-modal-footer {
            padding: 16px 20px;
            border-top: 1px solid var(--ap-glass-border);
            background: rgba(0,0,0,0.1);
        }
        
        @keyframes pulse { 
            0%, 100% { opacity: 1; } 
            50% { opacity: 0.7; } 
        }

        /* --- TOAST (iOS Notification Style) --- */
        #ap-toast {
            position: fixed;
            top: 24px;
            left: 50%;
            transform: translateX(-50%) translateY(-120px);
            background: var(--ap-glass-bg-elevated);
            backdrop-filter: blur(40px) saturate(180%);
            -webkit-backdrop-filter: blur(40px) saturate(180%);
            color: var(--ap-text-primary);
            padding: 12px 20px;
            border-radius: 980px;
            box-shadow: 
                0 0 0 0.5px rgba(255,255,255,0.1) inset,
                0 12px 40px rgba(0,0,0,0.4);
            display: flex;
            align-items: center;
            gap: 10px;
            z-index: 2147483649;
            transition: transform 0.5s var(--ap-ease-spring);
            font-size: 13px;
            font-weight: 500;
            letter-spacing: -0.1px;
            border: 1px solid var(--ap-glass-border-highlight);
        }

        #ap-toast.show { 
            transform: translateX(-50%) translateY(0); 
        }

        .ap-spin { 
            animation: spin 1s infinite linear; 
            display: block; 
        }

        @keyframes spin {
            100% { transform: rotate(360deg); }
        }

        /* ═══════════════════════════════════════════════════════════════
           BOTÕES DE DISPARO RÁPIDO (na barra de envio de mensagens)
           ═══════════════════════════════════════════════════════════════ */
        .send-message-options-container:has(.ap-quick-bar) {
            display: flex;
            align-items: center;
        }
        .ap-quick-bar {
            display: flex;
            flex: 1 1 auto;
            min-width: 0;
            gap: 6px;
            align-items: center;
            overflow-x: auto;
            overflow-y: hidden;
            margin-right: 12px;
            padding: 2px 0;
            scrollbar-width: thin;
        }
        .ap-quick-bar.ap-empty { display: none; }
        .ap-quick-bar::-webkit-scrollbar { height: 5px; }
        .ap-quick-bar::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.2); border-radius: 3px; }
        .ap-quick-btn {
            flex: 0 0 auto;
            white-space: nowrap;
            font-family: var(--ap-font);
            font-size: 12px;
            font-weight: 600;
            letter-spacing: -0.1px;
            color: #fff;
            background: var(--ap-qb-color, #0A84FF);
            border: none;
            border-radius: 8px;
            padding: 6px 12px;
            cursor: pointer;
            transition: transform .12s ease, filter .12s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.18);
        }
        .ap-quick-btn:hover { filter: brightness(1.08); transform: translateY(-1px); }
        .ap-quick-btn:active { transform: translateY(0); }
        .ap-quick-btn.has-tag::after { content: '🏷️'; font-size: 9px; margin-left: 5px; opacity: .85; }

        /* --- Config dos botões (dentro do modal de Configurações) --- */
        .ap-quick-list { display: flex; flex-direction: column; gap: 6px; margin: 8px 0; }
        .ap-quick-empty { font-size: 11px; color: var(--ap-text-tertiary); padding: 8px; text-align: center; }
        .ap-quick-row {
            display: flex; align-items: center; justify-content: space-between; gap: 8px;
            background: rgba(0,0,0,0.25); border: 1px solid var(--ap-glass-border);
            border-radius: 10px; padding: 8px 10px;
        }
        .ap-quick-row-main { display: flex; align-items: center; gap: 8px; min-width: 0; }
        .ap-quick-row-label {
            font-size: 13px; color: var(--ap-text-primary); font-weight: 600;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 140px;
        }
        .ap-quick-dot { width: 10px; height: 10px; border-radius: 50%; flex: 0 0 auto; }
        .ap-quick-tagchip {
            font-size: 10px; color: var(--ap-text-secondary); background: rgba(255,255,255,0.06);
            border-radius: 6px; padding: 2px 6px; white-space: nowrap;
        }
        .ap-quick-row-actions { display: flex; gap: 4px; flex: 0 0 auto; }
        .ap-quick-row-actions button {
            background: rgba(255,255,255,0.06); border: none; color: var(--ap-text-secondary);
            width: 24px; height: 24px; border-radius: 6px; cursor: pointer; font-size: 11px;
            transition: background .12s, color .12s;
        }
        .ap-quick-row-actions button:hover:not(:disabled) { background: var(--ap-accent-color); color: #fff; }
        .ap-quick-row-actions button:disabled { opacity: .3; cursor: default; }
        .ap-quick-editor {
            margin-top: 10px; padding: 12px; background: rgba(0,0,0,0.2);
            border: 1px solid var(--ap-glass-border); border-radius: 12px;
        }
        .ap-quick-colors { display: flex; gap: 8px; flex-wrap: wrap; }
        .ap-color-sw {
            width: 24px; height: 24px; border-radius: 50%; cursor: pointer;
            border: 2px solid transparent; transition: transform .12s;
        }
        .ap-color-sw:hover { transform: scale(1.1); }
        .ap-color-sw.selected { border-color: #fff; box-shadow: 0 0 0 2px var(--ap-accent-color); }
        .ap-btn-secondary {
            background: rgba(255,255,255,0.08); color: var(--ap-text-primary);
            border: 1px solid var(--ap-glass-border); border-radius: 10px;
            padding: 9px 14px; font-size: 13px; font-weight: 600; cursor: pointer;
            font-family: var(--ap-font); transition: background .12s; width: 100%;
        }
        .ap-btn-secondary:hover { background: rgba(255,255,255,0.14); }
    `;
    document.head.appendChild(style);
}

// -----------------------------------------------------------------------------
// 2. HELPERS
// -----------------------------------------------------------------------------

function parseSimpleMarkdown(text) {
    if (!text) return '';
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/`(.*?)`/g, '<code>$1</code>')
        .replace(/^\s*-\s+(.*)$/gm, '• $1<br>')
        .replace(/\n/g, '<br>');
}

function sanitizeNumber(value) {
    if (typeof value === 'number') return value;
    if (typeof value === 'string') {
        // Remove tudo que não for dígito ou ponto/vírgula
        const clean = value.replace(/[^\d,.-]/g, '').replace(',', '.');
        return parseFloat(clean) || 0;
    }
    return 0;
}

function formatCurrencyBR(value) {
    if (value === undefined || value === null) return '';
    // Garante que é um número
    const number = typeof value === 'string' ? parseFloat(value) : value;
    if (isNaN(number)) return '';

    // Formata para o padrão brasileiro: X.XXX,XX
    return number.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// -----------------------------------------------------------------------------
// 3. COMPONENTES DE UI
// -----------------------------------------------------------------------------

function renderSidebarContent() {
    const sidebar = document.getElementById('ap-sidebar');
    if (!sidebar) return;

    // Remove conteúdo anterior mantendo o handle
    let contentContainer = document.getElementById('ap-sidebar-content');
    if (!contentContainer) {
        contentContainer = document.createElement('div');
        contentContainer.id = 'ap-sidebar-content';
        contentContainer.style.height = '100%';
        contentContainer.style.display = 'flex';
        contentContainer.style.flexDirection = 'column';
        sidebar.appendChild(contentContainer);
    }
    contentContainer.innerHTML = '';

    if (!STATE.user) {
        // TELA DE LOGIN
        const loginContainer = document.createElement('div');
        loginContainer.className = 'ap-login-container';
        loginContainer.innerHTML = `
            <div class="ap-login-icon">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="rgba(10,132,255,0.9)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                </svg>
            </div>
            <div class="ap-login-logo">Auto-Proposal</div>
            <div class="ap-login-subtitle">Autentique-se para acessar<br>o sistema de propostas inteligentes.</div>
            
            <form id="ap-login-form" class="ap-login-form">
                <div class="ap-login-input-group">
                    <label class="ap-login-label">E-mail</label>
                    <input type="email" id="ap-login-email" class="ap-login-input" placeholder="seu@email.com" required>
                </div>
                <div class="ap-login-input-group">
                    <label class="ap-login-label">Senha</label>
                    <input type="password" id="ap-login-password" class="ap-login-input" placeholder="••••••••" required>
                </div>
                <div id="ap-login-error" class="ap-login-error">Credenciais inválidas.</div>
                <button type="submit" id="ap-login-btn" class="ap-login-button">Entrar no Sistema</button>
            </form>
            <div class="ap-footer" style="margin-top: auto; padding-top: 20px;">v1.0.1 • Multi-User</div>
        `;
        contentContainer.appendChild(loginContainer);

        document.getElementById('ap-login-form').addEventListener('submit', handleLogin);
    } else {
        // TELA PRINCIPAL (PROJETOS)
        const userPhotoUrl = getUserPhotoUrl(STATE.user.email);
        const avatarHtml = userPhotoUrl 
            ? `<img src="${userPhotoUrl}" alt="" class="ap-user-avatar">` 
            : `<div class="ap-user-avatar-fallback">${STATE.user.name.split(' ').map(n=>n[0]).join('').substring(0,2)}</div>`;

        const mainScreen = document.createElement('div');
        mainScreen.style.display = 'flex';
        mainScreen.style.flexDirection = 'column';
        mainScreen.style.height = '100%';
        mainScreen.innerHTML = `
            <div class="ap-header">
                <div class="ap-user-header">
                    ${avatarHtml}
                    <div>
                        <h2 style="margin-bottom: 2px; font-size: 15px;">Projetos em Potencial</h2>
                        <span style="font-size: 11px; color: var(--ap-text-secondary);">${STATE.user.name}</span>
                    </div>
                </div>
                <div style="display: flex; gap: 6px;">
                    <button id="ap-profile-btn" class="ap-icon-btn" title="Meu Perfil">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                    </button>
                    <button id="ap-settings-btn" class="ap-icon-btn" title="Configurações">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                    </button>
                    <button id="ap-logout-btn" class="ap-logout-btn" title="Sair">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                        Sair
                    </button>
                </div>
            </div>
            <div id="ap-project-list" class="ap-content">
                <div class="ap-empty-state">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom: 16px;"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                    <p>Use o atalho para analisar.</p>
                </div>
            </div>
            <div class="ap-footer">Auto-Proposal AI • v1.0.1</div>
        `;
        contentContainer.appendChild(mainScreen);

        document.getElementById('ap-profile-btn').addEventListener('click', (e) => { e.stopPropagation(); openProfile(); });
        document.getElementById('ap-settings-btn').addEventListener('click', (e) => { e.stopPropagation(); openSettings(); });
        document.getElementById('ap-logout-btn').addEventListener('click', (e) => { e.stopPropagation(); handleLogout(); });
        
        // Re-renderiza a lista de projetos se houver
        if (STATE.scrapedProjects.length > 0) {
            renderProjects(STATE.scrapedProjects);
        }
    }
}

async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('ap-login-email').value;
    const password = document.getElementById('ap-login-password').value;
    const btn = document.getElementById('ap-login-btn');
    const errorEl = document.getElementById('ap-login-error');

    btn.disabled = true;
    btn.innerText = 'Autenticando...';
    errorEl.style.display = 'none';

    try {
        const response = await fetch(`${STATE.settings.apiUrl}/api/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (data.success) {
            STATE.user = data.user;
            chrome.storage.local.set({ 'ap_user': data.user });
            loadQuickButtons();

            // Animação de sucesso
            const sidebar = document.getElementById('ap-sidebar');
            let contentContainer = document.getElementById('ap-sidebar-content');
            if (contentContainer) contentContainer.innerHTML = '';
            
            const successEl = document.createElement('div');
            successEl.className = 'ap-success-screen';
            successEl.innerHTML = `
                <div class="ap-success-circle"><div class="ap-success-check"></div></div>
                <div class="ap-success-title">Bem-vindo, ${data.user.name.split(' ')[0]}!</div>
                <div class="ap-success-sub">Autenticação realizada com sucesso.</div>
            `;
            if (contentContainer) {
                contentContainer.appendChild(successEl);
            } else {
                sidebar.appendChild(successEl);
            }
            setTimeout(() => {
                successEl.remove();
                renderSidebarContent();
            }, 2000);
        } else {
            errorEl.style.display = 'block';
            errorEl.innerText = data.error || 'Erro ao fazer login.';
        }
    } catch (err) {
        errorEl.style.display = 'block';
        errorEl.innerText = 'Erro ao conectar com a API.';
    } finally {
        btn.disabled = false;
        btn.innerText = 'Entrar no Sistema';
    }
}

function handleLogout() {
    STATE.user = null;
    STATE.quickButtons = [];
    renderAllQuickBars();
    chrome.storage.local.remove('ap_user');
    renderSidebarContent();
}

function createSidebar() {
    if (document.getElementById('ap-sidebar')) return;

    const sidebar = document.createElement('div');
    sidebar.id = 'ap-sidebar';
    sidebar.innerHTML = `
        <div id="ap-sidebar-handle" title="Abrir Auto-Proposal">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
        </div>
    `;

    document.body.appendChild(sidebar);
    
    // Impede que qualquer clique dentro da sidebar feche ela mesma
    sidebar.addEventListener('click', (e) => e.stopPropagation());
    
    // Verifica se já existe usuário salvo
    chrome.storage.local.get(['ap_user'], (result) => {
        if (result.ap_user) {
            STATE.user = result.ap_user;
        }
        renderSidebarContent();
        loadQuickButtons();
    });

    document.getElementById('ap-sidebar-handle').addEventListener('click', (e) => { e.stopPropagation(); if (STATE.isSidebarOpen) closeSidebar(); else openSidebar(); });

    document.addEventListener('click', (e) => {
        const sidebar = document.getElementById('ap-sidebar');
        const handle = document.getElementById('ap-sidebar-handle');
        const settingsModal = document.getElementById('ap-modal-overlay');
        if (STATE.isSidebarOpen && !sidebar.contains(e.target) && !handle.contains(e.target) && settingsModal && !settingsModal.contains(e.target)) {
            closeSidebar();
        }
    });
}

function createSettingsModal() {
    if (document.getElementById('ap-modal-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'ap-modal-overlay';
    overlay.innerHTML = `
        <div class="ap-modal" style="width: 540px;">
            <div class="ap-modal-header">
                <button id="ap-close-modal" class="ap-close-btn" title="Fechar"></button>
                <h3>Configurações</h3>
                <div style="width: 13px;"></div>
            </div>
            
            <div class="ap-modal-body">

                <!-- ═══ ABAS ═══ -->
                <div class="ap-tabs">
                    <button type="button" class="ap-tab-btn active" data-tab="geral">⚙️ Geral</button>
                    <button type="button" class="ap-tab-btn" data-tab="whatsapp">💬 WhatsApp</button>
                </div>

                <div id="ap-tab-geral" class="ap-tab-panel">

                <!-- ═══ IA PREFERIDA ═══ -->
                <div class="ap-input-group">
                    <label>🚀 IA Preferida (Primária)</label>
                    <select id="ap-preferred-provider" class="ap-select">
                        <option value="openai">OpenAI (GPT)</option>
                        <option value="claude">Anthropic (Claude)</option>
                        <option value="gemini">Google (Gemini) - Grátis</option>
                        <option value="groq">Groq (Llama/Mixtral) - Grátis</option>
                    </select>
                    <small style="color: var(--ap-text-tertiary); font-size: 10px;">Se falhar, o sistema tenta os demais providers automaticamente.</small>
                </div>

                <div class="ap-section-divider"></div>

                <!-- ═══ SEÇÕES DINÂMICAS ═══ -->
                <div id="ap-section-openai" class="ap-provider-section">
                    <div class="ap-input-group">
                        <label>Modelo OpenAI (Gerenciado via Backend)</label>
                        <select id="ap-openai-model" class="ap-select">
                            <option value="gpt-4o-mini">GPT-4o Mini (Ultra Barato)</option>
                            <option value="gpt-4o">GPT-4o (Equilibrado)</option>
                            <option value="gpt-5">GPT-5 (Forte p/ propostas - Recomendado)</option>
                            <option value="gpt-5.4">GPT-5.4 (Escrita topo)</option>
                            <option value="gpt-5.5">GPT-5.5 (Novo Flagship)</option>
                            <option value="gpt-5.5-pro">GPT-5.5 Pro (Potência Máxima)</option>
                        </select>
                    </div>
                </div>

                <div id="ap-section-claude" class="ap-provider-section ap-hidden">
                    <div class="ap-input-group">
                        <label>Modelo Claude (Gerenciado via Backend)</label>
                        <select id="ap-claude-model" class="ap-select">
                            <option value="claude-haiku-4-5">Claude Haiku 4.5 (Rápido)</option>
                            <option value="claude-sonnet-4-6">Claude Sonnet 4.6 (Recomendado)</option>
                            <option value="claude-opus-4-7">Claude Opus 4.7 (Poderoso)</option>
                        </select>
                    </div>
                </div>

                <div id="ap-section-gemini" class="ap-provider-section ap-hidden">
                    <div class="ap-input-group">
                        <label>🔑 Google Gemini API Keys (Grátis)</label>
                        <textarea id="ap-gemini-keys" class="ap-textarea" rows="2" placeholder="AIzaSy..."></textarea>
                    </div>
                </div>

                <div id="ap-section-groq" class="ap-provider-section ap-hidden">
                    <div class="ap-input-group">
                        <label>⚡ Groq API Keys (Grátis)</label>
                        <textarea id="ap-groq-keys" class="ap-textarea" rows="2" placeholder="gsk_..."></textarea>
                    </div>
                </div>

                <div class="ap-section-divider"></div>

                <!-- ═══ TABELA DE CUSTOS EXPANDIDA ═══ -->
                <div class="ap-input-group">
                    <label>💰 Comparativo de Custos (USD)</label>
                    <div style="background: rgba(0,0,0,0.3); border-radius: 10px; padding: 12px; border: 1px solid rgba(255,255,255,0.06); overflow-x: auto;">
                        <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: rgba(255,255,255,0.8);">
                            <thead>
                                <tr style="border-bottom: 1px solid rgba(255,255,255,0.1);">
                                    <th style="text-align: left; padding: 6px 4px; color: rgba(255,255,255,0.5); font-weight: 500;">Modelo</th>
                                    <th style="text-align: right; padding: 6px 4px; color: rgba(255,255,255,0.5); font-weight: 500;">100 Envios</th>
                                    <th style="text-align: right; padding: 6px 4px; color: rgba(255,255,255,0.5); font-weight: 500;">300 Envios</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td style="padding: 5px 4px;">🟢 Gemini / Groq</td><td style="text-align: right; padding: 5px 4px; color: #30D158;">$0,00</td><td style="text-align: right; padding: 5px 4px; color: #30D158; font-weight: 600;">$0,00</td></tr>
                                
                                <tr style="border-top: 1px solid rgba(255,255,255,0.06);"><td style="padding: 5px 4px;">🔵 GPT-4o Mini</td><td style="text-align: right; padding: 5px 4px;">$0,10</td><td style="text-align: right; padding: 5px 4px; font-weight: 600; color: #5CB8FF;">$0,31</td></tr>
                                <tr><td style="padding: 5px 4px;">🔵 GPT-4o</td><td style="text-align: right; padding: 5px 4px;">$1,70</td><td style="text-align: right; padding: 5px 4px; font-weight: 600; color: #5CB8FF;">$5,10</td></tr>
                                <tr><td style="padding: 5px 4px;">🔵 GPT-5.5</td><td style="text-align: right; padding: 5px 4px;">$4,10</td><td style="text-align: right; padding: 5px 4px; font-weight: 600; color: #5CB8FF;">$12,30</td></tr>
                                <tr><td style="padding: 5px 4px;">🔵 GPT-5.5 Pro</td><td style="text-align: right; padding: 5px 4px;">$24,60</td><td style="text-align: right; padding: 5px 4px; font-weight: 600; color: #5CB8FF;">$73,80</td></tr>
                                
                                <tr style="border-top: 1px solid rgba(255,255,255,0.06);"><td style="padding: 5px 4px;">🟣 Haiku 4.5</td><td style="text-align: right; padding: 5px 4px;">$0,75</td><td style="text-align: right; padding: 5px 4px; font-weight: 600; color: #BF5AF2;">$2,25</td></tr>
                                <tr><td style="padding: 5px 4px;">🟣 Sonnet 4.6</td><td style="text-align: right; padding: 5px 4px;">$2,25</td><td style="text-align: right; padding: 5px 4px; font-weight: 600; color: #BF5AF2;">$6,75</td></tr>
                                <tr><td style="padding: 5px 4px;">🟣 Opus 4.7</td><td style="text-align: right; padding: 5px 4px;">$3,75</td><td style="text-align: right; padding: 5px 4px; font-weight: 600; color: #BF5AF2;">$11,25</td></tr>
                            </tbody>
                        </table>
                        <div style="margin-top: 8px; font-size: 9px; color: var(--ap-text-tertiary); line-height: 1.4;">
                            * Estimativa base: 4.000 tokens input + 700 tokens output por proposta.<br>
                            * Modelos Gemini/Groq dependem de limites de cota gratuita (RPM).
                        </div>
                    </div>
                </div>

                <div class="ap-section-divider"></div>

                <!-- ═══ PLATAFORMA & PROMPTS ═══ -->
                <div class="ap-input-group">
                    <label>🌐 Plataforma Ativa</label>
                    <select id="ap-platform-select" class="ap-select">
                        <option value="99freelas">99freelas</option>
                        <option value="freelancer">Freelancer.com</option>
                        <option value="workana">Workana</option>
                    </select>
                </div>

                <div class="ap-input-group">
                    <label>👤 Seu Perfil Profissional</label>
                    <textarea id="ap-user-profile" class="ap-textarea" rows="4" placeholder="Ex: Sou desenvolvedor React Sênior..."></textarea>
                </div>

                <div class="ap-input-group">
                    <label>✍️ Prompt de Proposta</label>
                    <textarea id="ap-proposal-prompt" class="ap-textarea" rows="4" placeholder="Ex: Proposta curta e direta..."></textarea>
                </div>

                <div class="ap-section-divider"></div>

                <div class="ap-input-group">
                    <label>⌨️ Atalhos de Teclado</label>
                    
                    <div class="ap-shortcut-row">
                        <span>Analisar Lista de Projetos</span>
                        <button id="ap-shortcut-analyze" class="ap-shortcut-btn">Shift + P</button>
                    </div>

                    <div class="ap-shortcut-row">
                        <span>Gerar Proposta (Bid)</span>
                        <button id="ap-shortcut-generate" class="ap-shortcut-btn">Shift + G</button>
                    </div>

                    <div class="ap-shortcut-row">
                        <span>Disparo Rápido (último botão)</span>
                        <button id="ap-shortcut-quicksend" class="ap-shortcut-btn">Shift + M</button>
                    </div>
                </div>

                <div class="ap-section-divider"></div>

                <!-- ═══ BOTÕES DE DISPARO RÁPIDO (MENSAGENS) ═══ -->
                <div class="ap-input-group">
                    <label>⚡ Botões de Disparo Rápido (Mensagens)</label>
                    <small style="color: var(--ap-text-tertiary); font-size: 10px; display: block; margin-bottom: 6px;">Aparecem na barra de envio do chat do 99Freelas. Clicar envia a mensagem e aplica a etiqueta escolhida.</small>
                    <div id="ap-quick-list" class="ap-quick-list"></div>
                    <button type="button" id="ap-quick-add" class="ap-btn-secondary">+ Novo Botão</button>

                    <div id="ap-quick-editor" class="ap-quick-editor ap-hidden">
                        <div class="ap-input-group">
                            <label>Nome do Botão</label>
                            <input type="text" id="ap-quick-label" class="ap-input" placeholder="Ex: Follow-up 1" maxlength="40">
                        </div>
                        <div class="ap-input-group">
                            <label>Mensagem</label>
                            <textarea id="ap-quick-message" class="ap-textarea" rows="4" placeholder="Mensagem que será enviada ao cliente..."></textarea>
                        </div>
                        <div class="ap-input-group">
                            <label>Etiqueta (opcional)</label>
                            <select id="ap-quick-tag" class="ap-select"><option value="">(sem etiqueta)</option></select>
                            <small id="ap-quick-tag-note" style="color: var(--ap-warning); font-size: 10px; display: none; margin-top: 4px;">Abra a página de Mensagens do 99Freelas para carregar suas etiquetas.</small>
                        </div>
                        <div class="ap-input-group">
                            <label>Cor</label>
                            <div id="ap-quick-colors" class="ap-quick-colors"></div>
                        </div>
                        <div class="ap-input-group">
                            <label>Atalho de Teclado (opcional)</label>
                            <div class="ap-shortcut-row" style="margin-top: 4px;">
                                <span>Disparar este botão</span>
                                <div style="display: flex; gap: 6px; align-items: center;">
                                    <button type="button" id="ap-quick-shortcut" class="ap-shortcut-btn">Definir</button>
                                    <button type="button" id="ap-quick-shortcut-clear" class="ap-shortcut-btn" title="Limpar atalho" style="padding: 0 10px;">✕</button>
                                </div>
                            </div>
                        </div>
                        <div style="display: flex; gap: 8px;">
                            <button type="button" id="ap-quick-save" class="ap-btn-primary" style="flex: 1;">Salvar Botão</button>
                            <button type="button" id="ap-quick-cancel" class="ap-btn-secondary" style="flex: 0 0 auto; width: auto;">Cancelar</button>
                        </div>
                    </div>
                </div>

                <div class="ap-section-divider"></div>

                <!-- ═══ CONFIGURAÇÃO DO BACKEND ═══ -->
                <div class="ap-input-group">
                    <label>🔌 Conexão com sua API (Opcional)</label>
                    <input type="text" id="ap-api-url" class="ap-input" placeholder="https://seu-dominio.com">
                    <label class="ap-toggle" style="margin-top: 10px;">
                        <input type="checkbox" id="ap-use-backend">
                        <div class="ap-toggle-track"><div class="ap-toggle-thumb"></div></div>
                        <span class="ap-toggle-label">Usar Backend para Inteligência e BI</span>
                    </label>
                    <small style="color: var(--ap-text-tertiary); font-size: 10px; display: block; margin-top: 4px;">Ativando, a extensão enviará as propostas para sua API salvar no Postgres.</small>
                </div>

                <div class="ap-section-divider"></div>

                <label class="ap-toggle">
                    <input type="checkbox" id="ap-auto-mode">
                    <div class="ap-toggle-track"><div class="ap-toggle-thumb"></div></div>
                    <span class="ap-toggle-label">Modo Automático (Página de Proposta)</span>
                </label>

                <div class="ap-section-divider"></div>

                <!-- ═══ RADAR (AUTO-BID) ═══ -->
                <div class="ap-input-group">
                    <label>📡 Radar (Auto-Bid)</label>
                    <small style="color: var(--ap-text-tertiary); font-size: 10px; display: block; margin-bottom: 8px;">Vigia os projetos novos e ENVIA a proposta sozinho. Deixe uma aba aberta em <b>"Novos Projetos"</b> (/project-notifications/view) com o Radar ligado.</small>
                    <label class="ap-toggle">
                        <input type="checkbox" id="ap-radar-toggle">
                        <div class="ap-toggle-track"><div class="ap-toggle-thumb"></div></div>
                        <span class="ap-toggle-label">Ligar Radar (envio 100% automático)</span>
                    </label>
                    <div style="display: flex; gap: 8px; margin-top: 10px;">
                        <button type="button" id="ap-radar-start" class="ap-btn-primary" style="flex: 1;">▶ Iniciar Radar agora</button>
                        <button type="button" id="ap-radar-stop" class="ap-btn-secondary" style="flex: 0 0 auto; width: auto;">⏹ Parar</button>
                    </div>
                    <div style="display: flex; gap: 10px; margin-top: 10px;">
                        <div style="flex: 0 0 110px;">
                            <label style="font-size: 10px;">Intervalo (s)</label>
                            <input type="number" id="ap-radar-interval" class="ap-input" min="5" max="120" value="8">
                        </div>
                        <div style="flex: 1 1 auto;">
                            <label style="font-size: 10px;">Filtro por palavras (opcional, vazio = todos)</label>
                            <input type="text" id="ap-radar-keywords" class="ap-input" placeholder="ex: react, node, api, automação">
                        </div>
                    </div>
                    <div id="ap-radar-status" style="margin-top: 8px; font-size: 11px; color: var(--ap-text-secondary);"></div>
                </div>

                </div><!-- /ap-tab-geral -->

                <!-- ═══ ABA WHATSAPP ═══ -->
                <div id="ap-tab-whatsapp" class="ap-tab-panel ap-hidden">

                    <!-- Conexão -->
                    <div class="ap-input-group">
                        <label>📱 Conexão do WhatsApp</label>
                        <small style="color: var(--ap-text-tertiary); font-size: 10px; display: block; margin-bottom: 6px;">Conecte o WhatsApp que vai <b>enviar</b> os avisos. Use um número dedicado (não precisa ser o seu principal).</small>
                        <div id="ap-wa-status" class="ap-wa-status">Verificando conexão...</div>
                        <div style="display: flex; gap: 8px; margin-top: 10px;">
                            <button type="button" id="ap-wa-connect" class="ap-btn-primary" style="flex: 1;">📷 Conectar (QR Code)</button>
                            <button type="button" id="ap-wa-refresh" class="ap-btn-secondary" style="flex: 0 0 auto; width: auto;">↻ Status</button>
                        </div>
                        <div id="ap-wa-qr" class="ap-wa-qr ap-hidden">
                            <img id="ap-wa-qr-img" alt="QR Code" />
                            <small>WhatsApp → <b>Aparelhos conectados</b> → <b>Conectar aparelho</b> → escaneie o código acima.</small>
                        </div>
                    </div>

                    <div class="ap-section-divider"></div>

                    <!-- Grupo destino -->
                    <div class="ap-input-group">
                        <label>👥 Grupo que vai receber os avisos</label>
                        <small style="color: var(--ap-text-tertiary); font-size: 10px; display: block; margin-bottom: 6px;">Crie um grupo no WhatsApp (pode ser só você + o número conectado), depois clique em <b>Carregar</b> e selecione-o abaixo.</small>
                        <div style="display: flex; gap: 8px;">
                            <select id="ap-wa-group" class="ap-select" style="flex: 1;"><option value="">Carregue os grupos...</option></select>
                            <button type="button" id="ap-wa-load-groups" class="ap-btn-secondary" style="flex: 0 0 auto; width: auto;">↻ Carregar</button>
                        </div>
                    </div>

                    <div class="ap-section-divider"></div>

                    <!-- Aviso de mensagens -->
                    <div class="ap-input-group">
                        <label>🔔 Aviso de Mensagens do 99freelas</label>
                        <small style="color: var(--ap-text-tertiary); font-size: 10px; display: block; margin-bottom: 8px;">Vigia o contador de mensagens do 99freelas e te avisa no grupo do WhatsApp. Reavisa a cada 5 minutos até você ler as mensagens no site. Precisa de uma aba do 99freelas aberta.</small>
                        <label class="ap-toggle">
                            <input type="checkbox" id="ap-msg-toggle">
                            <div class="ap-toggle-track"><div class="ap-toggle-thumb"></div></div>
                            <span class="ap-toggle-label">Ligar aviso de mensagens no WhatsApp</span>
                        </label>
                        <div style="display: flex; gap: 8px; margin-top: 10px;">
                            <button type="button" id="ap-msg-test" class="ap-btn-secondary" style="flex: 1;">✉️ Enviar teste</button>
                        </div>
                        <div id="ap-msg-status" style="margin-top: 8px; font-size: 11px; color: var(--ap-text-secondary);"></div>
                    </div>

                </div><!-- /ap-tab-whatsapp -->
            </div>

            <div class="ap-modal-footer">
                <button id="ap-save-settings" class="ap-btn-primary">Salvar Alterações</button>
            </div>
        </div>
    `;

    document.body.appendChild(overlay);

    document.getElementById('ap-close-modal').addEventListener('click', closeSettings);
    document.getElementById('ap-save-settings').addEventListener('click', saveSettings);

    // Platform select change handler
    const platformSelect = document.getElementById('ap-platform-select');
    platformSelect.addEventListener('change', (e) => {
        const platform = e.target.value;
        // Salva os valores atuais antes de trocar
        const currentPlatform = STATE.settings.activePlatform;
        const currentProfile = document.getElementById('ap-user-profile').value.trim();
        const currentPrompt = document.getElementById('ap-proposal-prompt').value.trim();

        STATE.settings[`userProfile_${currentPlatform}`] = currentProfile;
        STATE.settings[`proposalPrompt_${currentPlatform}`] = currentPrompt;

        // Carrega os valores da nova plataforma
        STATE.settings.activePlatform = platform;
        document.getElementById('ap-user-profile').value = STATE.settings[`userProfile_${platform}`] || '';
        document.getElementById('ap-proposal-prompt').value = STATE.settings[`proposalPrompt_${platform}`] || '';
    });

    // Shortcut Logic
    const btnAnalyze = document.getElementById('ap-shortcut-analyze');
    btnAnalyze.addEventListener('click', () => recordShortcut('analyze', btnAnalyze));

    const btnGenerate = document.getElementById('ap-shortcut-generate');
    btnGenerate.addEventListener('click', () => recordShortcut('generate', btnGenerate));

    const btnQuickSend = document.getElementById('ap-shortcut-quicksend');
    btnQuickSend.addEventListener('click', () => recordShortcut('quickSend', btnQuickSend));

    // Botões de Disparo Rápido (CRUD)
    document.getElementById('ap-quick-add').addEventListener('click', () => openQuickEditor(null));
    document.getElementById('ap-quick-save').addEventListener('click', saveQuickFromEditor);
    document.getElementById('ap-quick-cancel').addEventListener('click', closeQuickEditor);
    document.getElementById('ap-quick-shortcut').addEventListener('click', () => recordQuickShortcut(document.getElementById('ap-quick-shortcut')));
    document.getElementById('ap-quick-shortcut-clear').addEventListener('click', () => { apEditorShortcut = null; updateQuickShortcutLabel(); });

    // Configurações de API Cluster

    // Abas (Geral / WhatsApp)
    overlay.querySelectorAll('.ap-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => switchSettingsTab(btn.dataset.tab));
    });

    // Aba WhatsApp: ações
    document.getElementById('ap-wa-connect').addEventListener('click', whatsappConnect);
    document.getElementById('ap-wa-refresh').addEventListener('click', () => whatsappRefreshStatus(true));
    document.getElementById('ap-wa-load-groups').addEventListener('click', whatsappLoadGroups);
    document.getElementById('ap-msg-test').addEventListener('click', whatsappSendTest);

    const groupSel = document.getElementById('ap-wa-group');
    groupSel.addEventListener('change', () => {
        const opt = groupSel.options[groupSel.selectedIndex];
        chrome.storage.local.set({
            [AP_MSG_KEYS.group]: groupSel.value,
            [AP_MSG_KEYS.groupName]: opt ? opt.textContent : ''
        });
    });

    const msgToggle = document.getElementById('ap-msg-toggle');
    msgToggle.addEventListener('change', () => {
        const on = msgToggle.checked;
        chrome.storage.local.set({ [AP_MSG_KEYS.on]: on });
        if (on) {
            chrome.storage.local.get([AP_MSG_KEYS.group], (r) => {
                if (!r[AP_MSG_KEYS.group]) {
                    msgToggle.checked = false;
                    chrome.storage.local.set({ [AP_MSG_KEYS.on]: false });
                    showToast('⚠️ Selecione um grupo antes de ligar o aviso.');
                    return;
                }
                startMessageMonitor();
                showToast('🔔 Aviso de mensagens ligado!');
            });
        } else {
            stopMessageMonitor();
            showToast('Aviso de mensagens desligado.');
        }
    });

    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeSettings(); });
}

function switchSettingsTab(tab) {
    document.querySelectorAll('.ap-tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    const geral = document.getElementById('ap-tab-geral');
    const wa = document.getElementById('ap-tab-whatsapp');
    if (geral) geral.classList.toggle('ap-hidden', tab !== 'geral');
    if (wa) wa.classList.toggle('ap-hidden', tab !== 'whatsapp');
    if (tab === 'whatsapp') whatsappRefreshStatus(false);
}

// -----------------------------------------------------------------------------
// ABA WHATSAPP — conexão, grupos e teste
// -----------------------------------------------------------------------------

function whatsappSetStatus(text, cls) {
    const el = document.getElementById('ap-wa-status');
    if (!el) return;
    el.textContent = text;
    el.className = 'ap-wa-status' + (cls ? ' ' + cls : '');
}

function whatsappRefreshStatus(showToastMsg) {
    whatsappSetStatus('Verificando conexão...', 'connecting');
    chrome.runtime.sendMessage({ action: 'evoStatus' }, (resp) => {
        if (!resp || !resp.success) {
            whatsappSetStatus('Erro ao verificar: ' + (resp?.error || 'sem resposta'), 'disconnected');
            return;
        }
        const state = resp.state;
        if (state === 'open') {
            whatsappSetStatus('✅ Conectado', 'connected');
            const qr = document.getElementById('ap-wa-qr');
            if (qr) qr.classList.add('ap-hidden');
            if (showToastMsg) showToast('✅ WhatsApp conectado.');
        } else if (state === 'connecting') {
            whatsappSetStatus('⏳ Aguardando leitura do QR Code...', 'connecting');
        } else {
            whatsappSetStatus('❌ Desconectado — clique em Conectar', 'disconnected');
        }
    });
}

function whatsappConnect() {
    whatsappSetStatus('Gerando QR Code...', 'connecting');
    chrome.runtime.sendMessage({ action: 'evoConnect' }, (resp) => {
        if (!resp || !resp.success) {
            whatsappSetStatus('Erro ao gerar QR: ' + (resp?.error || 'sem resposta'), 'disconnected');
            return;
        }
        const qr = document.getElementById('ap-wa-qr');
        const img = document.getElementById('ap-wa-qr-img');
        if (resp.base64 && img && qr) {
            img.src = resp.base64;
            qr.classList.remove('ap-hidden');
            whatsappSetStatus('📷 Escaneie o QR Code abaixo', 'connecting');
            // Repõe o status automaticamente enquanto o usuário escaneia
            let tries = 0;
            const poll = setInterval(() => {
                tries++;
                chrome.runtime.sendMessage({ action: 'evoStatus' }, (r) => {
                    if (r && r.success && r.state === 'open') {
                        clearInterval(poll);
                        whatsappSetStatus('✅ Conectado', 'connected');
                        qr.classList.add('ap-hidden');
                        showToast('✅ WhatsApp conectado!');
                    }
                });
                if (tries > 40) clearInterval(poll); // ~2min
            }, 3000);
        } else {
            whatsappSetStatus('✅ Já conectado (sem QR necessário)', 'connected');
        }
    });
}

function whatsappLoadGroups() {
    const sel = document.getElementById('ap-wa-group');
    if (!sel) return;
    sel.innerHTML = '<option value="">Carregando...</option>';
    chrome.runtime.sendMessage({ action: 'evoGroups' }, (resp) => {
        if (!resp || !resp.success) {
            sel.innerHTML = '<option value="">Erro: ' + (resp?.error || 'sem resposta') + '</option>';
            return;
        }
        if (!resp.groups.length) {
            sel.innerHTML = '<option value="">Nenhum grupo encontrado</option>';
            return;
        }
        chrome.storage.local.get([AP_MSG_KEYS.group], (r) => {
            const saved = r[AP_MSG_KEYS.group] || '';
            sel.innerHTML = '<option value="">Selecione um grupo...</option>';
            resp.groups.forEach(g => {
                const opt = document.createElement('option');
                opt.value = g.id;
                opt.textContent = g.subject;
                if (g.id === saved) opt.selected = true;
                sel.appendChild(opt);
            });
        });
    });
}

function whatsappSendTest() {
    chrome.storage.local.get([AP_MSG_KEYS.group], (r) => {
        const group = r[AP_MSG_KEYS.group];
        if (!group) { showToast('⚠️ Selecione um grupo primeiro.'); return; }
        const statusEl = document.getElementById('ap-msg-status');
        if (statusEl) statusEl.textContent = 'Enviando teste...';
        // Usa a contagem real da página; se não houver, simula com um exemplo (idêntico ao aviso real)
        const realCount = msgGetCount();
        const count = realCount > 0 ? realCount : 3;
        chrome.runtime.sendMessage({
            action: 'evoSendText',
            to: group,
            text: msgBuildText(count)
        }, (resp) => {
            if (resp && resp.success) {
                if (statusEl) statusEl.textContent = '✅ Teste enviado com sucesso.';
                showToast('✅ Mensagem de teste enviada.');
            } else {
                if (statusEl) statusEl.textContent = '❌ Falha: ' + (resp?.error || 'sem resposta');
            }
        });
    });
}

function createToast() {
    if (document.getElementById('ap-toast')) return;
    const toast = document.createElement('div');
    toast.id = 'ap-toast';
    document.body.appendChild(toast);
}

// -----------------------------------------------------------------------------
// 4. LÓGICA DE UI & SHORTCUTS
// -----------------------------------------------------------------------------

function openSidebar() {
    const sidebar = document.getElementById('ap-sidebar');
    STATE.isSidebarOpen = true;
    sidebar.classList.add('open');
    // Esconde o handle enquanto a sidebar está aberta
    document.getElementById('ap-sidebar-handle').style.opacity = '0';
}

function closeSidebar() {
    const sidebar = document.getElementById('ap-sidebar');
    STATE.isSidebarOpen = false;
    sidebar.classList.remove('open');
    // FIX CRÍTICO: Limpa o estilo inline para que o CSS (.visible) volte a funcionar no hover
    document.getElementById('ap-sidebar-handle').style.opacity = '';
}

function openSettings() {
    const geminiKeys = STATE.settings.geminiKeys || [];
    const groqKeys = STATE.settings.groqKeys || [];
    const openaiKeys = STATE.settings.openaiKeys || [];
    const claudeKeys = STATE.settings.claudeKeys || [];

    document.getElementById('ap-gemini-keys').value = (STATE.settings.geminiKeys || []).join('\n');
    document.getElementById('ap-groq-keys').value = (STATE.settings.groqKeys || []).join('\n');

    // Modelos e provider preferido
    document.getElementById('ap-openai-model').value = STATE.settings.openaiModel || 'gpt-4o-mini';
    document.getElementById('ap-claude-model').value = STATE.settings.claudeModel || 'claude-haiku-4-5';
    document.getElementById('ap-preferred-provider').value = STATE.settings.preferredProvider || 'openai';

    // Função para alternar visibilidade das seções
    const updateVisibleSections = (provider) => {
        document.querySelectorAll('.ap-provider-section').forEach(s => s.classList.add('ap-hidden'));
        const activeSection = document.getElementById(`ap-section-${provider}`);
        if (activeSection) activeSection.classList.remove('ap-hidden');
    };

    updateVisibleSections(STATE.settings.preferredProvider || 'openai');

    document.getElementById('ap-preferred-provider').addEventListener('change', (e) => {
        updateVisibleSections(e.target.value);
    });

    const platform = CURRENT_SITE;
    document.getElementById('ap-platform-select').value = platform;
    document.getElementById('ap-user-profile').value = STATE.settings[`userProfile_${platform}`] || STATE.settings.userProfile || '';
    document.getElementById('ap-proposal-prompt').value = STATE.settings[`proposalPrompt_${platform}`] || STATE.settings.proposalPrompt || '';

    document.getElementById('ap-auto-mode').checked = STATE.settings.autoProposalMode;
    document.getElementById('ap-api-url').value = STATE.settings.apiUrl || 'http://localhost:3000';
    document.getElementById('ap-use-backend').checked = STATE.settings.useBackend || false;

    // Garante que as chaves existem antes de acessar
    const scAnalyze = STATE.settings.shortcuts.analyze || { modifier: 'Shift', key: 'P' };
    const scGenerate = STATE.settings.shortcuts.generate || { modifier: 'Shift', key: 'G' };
    const scQuick = STATE.settings.shortcuts.quickSend || { modifier: 'Shift', key: 'M' };

    document.getElementById('ap-shortcut-analyze').innerText = `${scAnalyze.modifier} + ${scAnalyze.key}`;
    document.getElementById('ap-shortcut-generate').innerText = `${scGenerate.modifier} + ${scGenerate.key}`;
    document.getElementById('ap-shortcut-quicksend').innerText = `${scQuick.modifier} + ${scQuick.key}`;

    // Botões de disparo rápido
    closeQuickEditor();
    renderQuickButtonsConfig();

    // Aba WhatsApp: carrega toggle + grupo salvo e reinicia na aba Geral
    switchSettingsTab('geral');
    chrome.storage.local.get([AP_MSG_KEYS.on, AP_MSG_KEYS.group, AP_MSG_KEYS.groupName], (r) => {
        const toggle = document.getElementById('ap-msg-toggle');
        if (toggle) toggle.checked = !!r[AP_MSG_KEYS.on];
        const sel = document.getElementById('ap-wa-group');
        if (sel && r[AP_MSG_KEYS.group]) {
            sel.innerHTML = '';
            const opt = document.createElement('option');
            opt.value = r[AP_MSG_KEYS.group];
            opt.textContent = r[AP_MSG_KEYS.groupName] || r[AP_MSG_KEYS.group];
            opt.selected = true;
            sel.appendChild(opt);
        }
    });

    document.getElementById('ap-modal-overlay').classList.add('show');
}

function closeSettings() {
    document.getElementById('ap-modal-overlay').classList.remove('show');
}

function saveSettings() {
    const geminiKeysRaw = document.getElementById('ap-gemini-keys').value;
    const groqKeysRaw = document.getElementById('ap-groq-keys').value;
    
    // Converte texto em array, removendo espaços e linhas vazias
    const geminiKeys = geminiKeysRaw.split('\n').map(k => k.trim()).filter(k => k.length > 0);
    const groqKeys = groqKeysRaw.split('\n').map(k => k.trim()).filter(k => k.length > 0);

    const openaiModel = document.getElementById('ap-openai-model').value;
    const claudeModel = document.getElementById('ap-claude-model').value;
    const preferredProvider = document.getElementById('ap-preferred-provider').value;

    const activePlatform = document.getElementById('ap-platform-select').value;
    const userProfile = document.getElementById('ap-user-profile').value.trim();
    const proposalPrompt = document.getElementById('ap-proposal-prompt').value.trim();
    const autoProposalMode = document.getElementById('ap-auto-mode').checked;
    const apiUrl = document.getElementById('ap-api-url').value.trim();
    const useBackend = document.getElementById('ap-use-backend').checked;

    const shortcuts = STATE.settings.shortcuts;

    // Salva os prompts na plataforma ativa
    STATE.settings[`userProfile_${activePlatform}`] = userProfile;
    STATE.settings[`proposalPrompt_${activePlatform}`] = proposalPrompt;

    // Atualiza o estado global
    STATE.settings = {
        ...STATE.settings,
        geminiKeys,
        groqKeys,
        openaiModel,
        claudeModel,
        preferredProvider,
        activePlatform,
        userProfile,
        proposalPrompt,
        autoProposalMode,
        apiUrl,
        useBackend,
        shortcuts
    };

    chrome.storage.local.set(STATE.settings, () => {
        showToast("✅ Configurações salvas.");
        closeSettings();
    });
}

function recordShortcut(actionName, btnElement) {
    const originalText = btnElement.innerText;
    btnElement.innerText = "Detectando...";
    btnElement.classList.add('recording');

    function handleKey(e) {
        e.preventDefault();
        e.stopPropagation();
        if (['Shift', 'Control', 'Alt', 'Meta', 'Command'].includes(e.key)) return;

        let modifier = '';
        if (e.shiftKey) modifier = 'Shift';
        else if (e.ctrlKey) modifier = 'Ctrl';
        else if (e.altKey) modifier = 'Alt';
        else if (e.metaKey) modifier = 'Cmd';

        if (modifier && e.key) {
            const key = e.key.toUpperCase();
            STATE.settings.shortcuts[actionName] = { modifier, key };
            btnElement.innerText = `${modifier} + ${key}`;
            cleanup();
        }
    }

    function cleanup() {
        btnElement.classList.remove('recording');
        document.removeEventListener('keydown', handleKey, true);
        document.removeEventListener('click', cancelClick, true);
    }

    function cancelClick(e) {
        if (e.target !== btnElement) {
            btnElement.innerText = originalText;
            cleanup();
        }
    }

    document.addEventListener('keydown', handleKey, true);
    setTimeout(() => document.addEventListener('click', cancelClick, true), 100);
}

let toastTimeout;
function showToast(message, type = 'normal') {
    const toast = document.getElementById('ap-toast');
    if (toastTimeout) clearTimeout(toastTimeout);

    if (type === 'loading') {
        toast.innerHTML = `
            <svg class="ap-spin" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>
            <span>${message}</span>
        `;
        toast.classList.add('show');
    } else {
        toast.innerHTML = `<span>${message}</span>`;
        toast.classList.add('show');
        toastTimeout = setTimeout(() => { toast.classList.remove('show'); }, 3000);
    }
}

// -----------------------------------------------------------------------------
// 5. LÓGICA: FILTRO DE PROJETOS (SIDEBAR)
// -----------------------------------------------------------------------------

// Dispatcher: escolhe a função correta baseada no site
async function scrapeProjectsFromPage() {
    if (CURRENT_SITE === 'freelancer') {
        return await scrapeProjectsFreelancer();
    }
    if (CURRENT_SITE === 'workana') {
        return scrapeProjectsWorkana();
    }
    return scrapeProjects99freelas();
}

// Scraper específico para 99freelas
function scrapeProjects99freelas() {
    const items = document.querySelectorAll('.result-list > li.result-item');
    return Array.from(items).map(li => {
        const titleEl = li.querySelector('.title a');
        const descEl = li.querySelector('.item-text.description');
        let fullDescription = '';
        if (descEl) {
            const clone = descEl.cloneNode(true);
            if (clone.querySelector('.read-more')) clone.querySelector('.read-more').remove();
            if (clone.querySelector('.read-less')) clone.querySelector('.read-less').remove();
            clone.querySelectorAll('br').forEach(br => br.replaceWith('\n'));
            fullDescription = clone.textContent.trim();
        }

        // Modificação: Transforma URL de detalhes em URL de proposta (Bid)
        let originalUrl = titleEl ? titleEl.href : '#';
        let bidUrl = originalUrl.replace('/project/', '/project/bid/');

        return {
            id: li.getAttribute('data-id'),
            title: titleEl ? titleEl.innerText.trim() : 'Sem título',
            description: fullDescription,
            url: bidUrl
        };
    });
}

// Scraper específico para Freelancer.com
async function scrapeProjectsFreelancer() {
    const cards = document.querySelectorAll('fl-project-contest-card.ProjectCard');
    const projects = [];

    const esperar = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    console.log(`[Auto-Proposal] Freelancer: Encontrados ${cards.length} cards de projetos...`);

    for (const card of cards) {
        try {
            // Expandir descrição clicando em "Read More"
            const paragrafoDescricao = card.querySelector('p.mb-xxsmall');
            if (paragrafoDescricao) {
                const botaoMore = paragrafoDescricao.querySelector('.ReadMoreButton');
                if (botaoMore) {
                    botaoMore.click();
                    await esperar(150);
                }
            }

            // Título do Projeto
            const elTitulo = card.querySelector('.Title-text');
            const titulo = elTitulo ? elTitulo.innerText.trim() : "Sem Título";

            // URL do projeto - Estratégias de busca:
            // 1. Buscar link no wrapper pai (o card pode estar dentro de um <a>)
            // 2. Buscar qualquer link com href contendo /projects/
            // 3. Buscar link com fltrackinglabel
            let url = '#';

            // Estratégia 1: Verificar se o card está dentro de um link
            const parentLink = card.closest('a[href*="/projects/"]');
            if (parentLink) {
                url = parentLink.href;
            } else {
                // Estratégia 2: Buscar link em qualquer lugar próximo do card (irmãos ou ancestrais)
                const wrapper = card.parentElement;
                if (wrapper) {
                    const nearbyLink = wrapper.querySelector('a[href*="/projects/"]')
                        || wrapper.closest('a[href*="/projects/"]');
                    if (nearbyLink) {
                        url = nearbyLink.href;
                    }
                }
            }

            // Estratégia 3: Fallback - buscar dentro do card
            if (url === '#') {
                const innerLink = card.querySelector('a[href*="/projects/"]')
                    || card.querySelector('a[fltrackinglabel="RedirectToPVP"]');
                if (innerLink) {
                    url = innerLink.href;
                }
            }

            // Log para debug se não encontrou URL
            if (url === '#') {
                console.warn(`[Auto-Proposal] URL não encontrada para: "${titulo}"`);
            }

            // Descrição (sem botão)
            let descricao = "";
            if (paragrafoDescricao) {
                const cloneDesc = paragrafoDescricao.cloneNode(true);
                const btnNoClone = cloneDesc.querySelector('button');
                if (btnNoClone) btnNoClone.remove();
                descricao = cloneDesc.innerText.trim();
            }

            // ID único baseado no URL ou título
            const id = url !== '#'
                ? url.split('/').pop().split('?')[0]
                : titulo.toLowerCase().replace(/\s+/g, '-').substring(0, 50);

            projects.push({
                id: id,
                title: titulo,
                description: descricao,
                url: url
            });
        } catch (erro) {
            console.error("[Auto-Proposal] Erro ao processar card do Freelancer:", erro);
        }
    }

    return projects;
}

// Scraper específico para Workana
function scrapeProjectsWorkana() {
    const items = document.querySelectorAll('.project-item, .job-item');
    return Array.from(items).map(el => {
        const titleEl = el.querySelector('.project-title a, h2 a, h2.title a');
        const descEl = el.querySelector('.html-desc, .description, .specification');
        
        let originalUrl = titleEl ? titleEl.href : '#';
        // Workana de /job/slug para /messages/bid/slug
        let bidUrl = originalUrl.replace('/job/', '/messages/bid/');

        return {
            id: el.getAttribute('data-id') || Math.random().toString(36).substring(2),
            title: titleEl ? titleEl.innerText.trim() : 'Sem título',
            description: descEl ? descEl.innerText.trim() : '',
            url: bidUrl
        };
    });
}

function renderProjectCards(filteredProjects) {
    const container = document.getElementById('ap-project-list');
    container.innerHTML = '';
    if (filteredProjects.length === 0) {
        container.innerHTML = `<div class="ap-empty-state"><p>Nenhum projeto compatível.</p></div>`;
        return;
    }
    filteredProjects.forEach(project => {
        const card = document.createElement('div');
        card.className = 'ap-card';
        const displayContent = project.summary ? parseSimpleMarkdown(project.summary) : project.description;
        card.innerHTML = `<div class="ap-card-title">${project.title}</div><div class="ap-card-desc">${displayContent}</div>`;
        card.addEventListener('click', () => window.open(project.url, '_blank'));
        container.appendChild(card);
    });
}

async function runProjectAnalysis() {
    // Verificar se tem alguma API Key configurada (Cluster ou Solo)
    const hasGemini = (STATE.settings.geminiKeys && STATE.settings.geminiKeys.length > 0) || (STATE.settings.apiKey && STATE.settings.apiKey.trim().length > 0);
    const hasGroq = (STATE.settings.groqKeys && STATE.settings.groqKeys.length > 0) || (STATE.settings.groqApiKey && STATE.settings.groqApiKey.trim().length > 0);
    const hasOpenAI = STATE.settings.openaiKeys && STATE.settings.openaiKeys.length > 0;
    const hasClaude = STATE.settings.claudeKeys && STATE.settings.claudeKeys.length > 0;

    if (!hasGemini && !hasGroq && !hasOpenAI && !hasClaude) {
        showToast("⚠️ Configure ao menos uma API Key.");
        openSettings();
        return;
    }
    showToast("Analisando projetos...", "loading");

    // Aguarda o scraping (necessário para Freelancer.com que é async)
    const projects = await scrapeProjectsFromPage();
    if (projects.length === 0) { showToast("❌ Nenhum projeto na tela."); return; }

    STATE.scrapedProjects = projects;
    const projectsPayload = projects.map(p => ({ id: p.id, title: p.title, description: p.description }));
    const finalInstruction = `${SYSTEM_INSTRUCTION_TEMPLATE}\n${STATE.settings.userProfile}`;

    chrome.runtime.sendMessage({
        action: "aiRequest",
        taskType: "FILTER_PROJECTS",
        userId: STATE.user?.id,
        userName: STATE.user?.name,
        preferredProvider: STATE.settings.preferredProvider,
        apiUrl: STATE.settings.apiUrl,
        useBackend: STATE.settings.useBackend,
        geminiKeys: STATE.settings.geminiKeys || (STATE.settings.apiKey ? [STATE.settings.apiKey] : []),
        groqKeys: STATE.settings.groqKeys || (STATE.settings.groqApiKey ? [STATE.settings.groqApiKey] : []),
        openaiKeys: STATE.settings.openaiKeys,
        claudeKeys: STATE.settings.claudeKeys,
        openaiModel: STATE.settings.openaiModel,
        claudeModel: STATE.settings.claudeModel,
        groqModel: STATE.settings.groqModel,
        systemInstruction: finalInstruction,
        userPrompt: JSON.stringify(projectsPayload)
    }, (response) => {
        if (!response || !response.success) { showToast("❌ Erro na IA."); return; }
        const aiData = response.data;
        let finalProjects = [];
        if (Array.isArray(aiData) && aiData.length > 0 && aiData[0].id) {
            finalProjects = aiData.map(aiItem => {
                const original = STATE.scrapedProjects.find(p => p.id == aiItem.id);
                return original ? { ...original, summary: aiItem.summary } : null;
            }).filter(Boolean);
        } else {
            finalProjects = STATE.scrapedProjects.filter(p => aiData.includes(p.id));
        }
        renderProjectCards(finalProjects);
        showToast("✅ Projetos selecionados");
        if (!STATE.isSidebarOpen) setTimeout(() => openSidebar(), 500);
    });
}

// -----------------------------------------------------------------------------
// 6. LÓGICA: GERAÇÃO DE PROPOSTA (BID PAGE)
// -----------------------------------------------------------------------------

// Dispatcher: escolhe a função correta baseada no site
function scrapeProposalContext() {
    if (CURRENT_SITE === 'freelancer') {
        return scrapeProposalContextFreelancer();
    }
    if (CURRENT_SITE === 'workana') {
        return scrapeProposalContextWorkana();
    }
    return scrapeProposalContext99freelas();
}

// Dispatcher: escolhe a função correta baseada no site
function fillProposalForm(data) {
    if (CURRENT_SITE === 'freelancer') {
        return fillProposalFormFreelancer(data);
    }
    if (CURRENT_SITE === 'workana') {
        return fillProposalFormWorkana(data);
    }
    return fillProposalForm99freelas(data);
}

// Scraper de contexto para 99freelas
function scrapeProposalContext99freelas() {
    // 1. Nome do Cliente
    const clientEl = document.querySelector('.info-usuario-nome .name');
    const clientName = clientEl ? clientEl.innerText.trim() : 'Cliente';

    // 2. Descrição do Projeto
    const descEl = document.querySelector('.item-text.project-description');
    let description = '';
    if (descEl) {
        // Clona para não estragar o DOM visual
        const clone = descEl.cloneNode(true);
        clone.querySelectorAll('br').forEach(br => br.replaceWith('\n'));
        description = clone.textContent.trim();
    }

    // 3. Valor e Prazo Médios (Busca Robusta)
    let avgValue = 'Não informado';
    let avgTime = 'Não informado';

    // Estratégia 1: Selector clássico
    const infoEl = document.querySelector('.generic.information');
    if (infoEl) {
        const bTags = infoEl.querySelectorAll('b');
        if (bTags.length >= 1) avgValue = bTags[0].innerText.trim();
        if (bTags.length >= 2) avgTime = bTags[1].innerText.trim();
    }

    // Estratégia 2: Fallback para novos layouts/classes
    if (avgValue === 'Não informado') {
        const labels = document.querySelectorAll('.label-projeto, .info-label, strong');
        labels.forEach(lbl => {
            const txt = lbl.innerText.toLowerCase();
            if (txt.includes('valor') || txt.includes('orçamento')) {
                const val = lbl.nextElementSibling || lbl.parentElement.querySelector('b, span:not(.info-label)');
                if (val) avgValue = val.innerText.trim();
            }
            if (txt.includes('prazo')) {
                const val = lbl.nextElementSibling || lbl.parentElement.querySelector('b, span:not(.info-label)');
                if (val) avgTime = val.innerText.trim();
            }
        });
    }

    // Estratégia 3: Buscar em box-detalhes
    if (avgValue === 'Não informado') {
        const boxes = document.querySelectorAll('.box-projeto, .generic-box');
        boxes.forEach(box => {
            if (box.innerText.includes('Valor')) {
                const matches = box.innerText.match(/R\$\s?[\d.,]+\s?-\s?[\d.,]+/i);
                if (matches) avgValue = matches[0];
            }
        });
    }

    return { clientName, description, avgValue, avgTime };
}

// Scraper de contexto para Freelancer.com
function scrapeProposalContextFreelancer() {
    // 1. Título do Projeto (do card Project Details)
    let projectTitle = 'Projeto';
    const titleSelectors = [
        '.ProjectDetailsCard-title.mobile\\:hide',  // Título desktop
        '.ProjectDetailsCard-title',                 // Qualquer título
        'h1.PageProjectViewLogout-header-title',
        '.project-header h1'
    ];
    for (const selector of titleSelectors) {
        const titleEl = document.querySelector(selector);
        if (titleEl && titleEl.textContent.trim() !== 'Project Details') {
            projectTitle = titleEl.textContent.trim();
            break;
        }
    }

    // 2. Descrição do Projeto (do card Project Details)
    let description = '';
    const descSelectors = [
        'fl-interactive-text .ContentWrapper span',  // Estrutura exata do Freelancer
        '.ProjectDescription fl-interactive-text span',
        '.ProjectDescription span',
        'app-project-details-description span',
        '.project-details p'
    ];

    for (const selector of descSelectors) {
        const descEl = document.querySelector(selector);
        if (descEl) {
            description = descEl.textContent.trim();
            if (description && description.length > 50) break;
        }
    }

    // Fallback: buscar todo o conteúdo de ProjectDescription
    if (!description || description.length < 50) {
        const descContainer = document.querySelector('.ProjectDescription, app-project-details-description');
        if (descContainer) {
            description = descContainer.textContent.trim();
        }
    }

    // 3. Budget do projeto (do card Project Details)
    let avgValue = 'Não informado';
    const budgetSelectors = [
        '.ProjectViewDetails-budget p',              // Estrutura exata
        'app-project-details-budget p',
        '.BudgetPrice',
        '.project-budget'
    ];
    for (const selector of budgetSelectors) {
        const budgetEl = document.querySelector(selector);
        if (budgetEl) {
            avgValue = budgetEl.textContent.trim();
            if (avgValue) break;
        }
    }

    // 4. Prazo (bidding ends)
    let avgTime = 'A definir';
    const timeEl = document.querySelector('.ProjectViewDetails-budget fl-relative-time span');
    if (timeEl) {
        avgTime = 'Bidding ends in ' + timeEl.textContent.trim();
    }

    // 5. Skills do projeto (do card Project Details)
    let skills = '';
    const skillSelectors = [
        '.ProjectViewDetailsSkills fl-tag .Content',  // Estrutura exata
        '.ProjectViewDetailsSkills fl-tag',
        'app-project-details-skills fl-tag .Content',
        'app-project-details-skills fl-tag'
    ];

    for (const selector of skillSelectors) {
        const skillEls = document.querySelectorAll(selector);
        if (skillEls.length > 0) {
            skills = Array.from(skillEls).map(el => el.textContent.trim()).join(', ');
            break;
        }
    }

    // 6. Moeda do projeto (extraída do formulário de bid ou do budget)
    let currency = 'USD'; // Default
    const currencyEl = document.querySelector('#bidAmountInput')?.closest('.InputContainer')?.querySelector('.AfterLabel .LabelText');
    if (currencyEl) {
        currency = currencyEl.textContent.trim();
    } else {
        // Fallback: tentar extrair do budget (£250.00 – 750.00 GBP)
        const currencyMatch = avgValue.match(/([A-Z]{3})/);
        if (currencyMatch) {
            currency = currencyMatch[0];
        } else {
            // Tentar símbolo
            const symbolMatch = avgValue.match(/[$€£]/);
            if (symbolMatch) {
                const symbolMap = { '$': 'USD', '€': 'EUR', '£': 'GBP' };
                currency = symbolMap[symbolMatch[0]] || 'USD';
            }
        }
    }

    // 7. Project ID (opcional, para referência)
    let projectId = '';
    const idEl = document.querySelector('.ProjectDetailsFooter p');
    if (idEl && idEl.textContent.includes('Project ID:')) {
        projectId = idEl.textContent.replace('Project ID:', '').trim();
    }

    console.log('[Auto-Proposal] Contexto Freelancer:', {
        projectTitle,
        description: description.substring(0, 200) + '...',
        avgValue,
        skills,
        currency,
        projectId
    });

    return {
        clientName: projectTitle,
        description: description + (skills ? `\n\nSkills: ${skills}` : ''),
        avgValue: avgValue,
        avgTime: avgTime,
        currency: currency
    };
}

// Scraper de contexto para Workana
function scrapeProposalContextWorkana() {
    // 1. Nome do Cliente
    const clientEl = document.querySelector('.user-info h4, .client-box h4');
    const clientName = clientEl ? clientEl.innerText.trim() : 'Cliente';

    // 2. Descrição do Projeto
    const descEl = document.querySelector('.specification');
    let description = '';
    if (descEl) {
        const clone = descEl.cloneNode(true);
        clone.querySelectorAll('br').forEach(br => br.replaceWith('\n'));
        description = clone.textContent.trim();
    }

    // 3. Valor (Orçamento)
    const budgetEl = document.querySelector('.budget, h3.budget');
    const avgValue = budgetEl ? budgetEl.innerText.trim() : 'Não informado';

    // 4. Prazo
    const deadlineEl = document.querySelector('.deadline, p.deadline');
    const avgTime = deadlineEl ? deadlineEl.innerText.replace('Prazo de Entrega:', '').trim() : 'Não informado';

    // 5. Skills
    const skillEls = document.querySelectorAll('.skills .skill, p.skills a');
    const skills = Array.from(skillEls).map(el => el.textContent.trim()).join(', ');

    return {
        clientName,
        description: description + (skills ? `\n\nSkills: ${skills}` : ''),
        avgValue,
        avgTime
    };
}

// Preenchimento de formulário para Workana
function fillProposalFormWorkana(data) {
    // 1. Preencher Textarea da Proposta (caso seja o form clássico de texto único)
    const txtProposta = document.getElementById('BidContent');
    if (txtProposta) {
        txtProposta.value = data.message;
        txtProposta.dispatchEvent(new Event('input', { bubbles: true }));
        txtProposta.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // 1b. Caso existam perguntas específicas do projeto (formulário estruturado do Workana)
    const questionsContainer = document.getElementById('projectQuestions');
    if (questionsContainer) {
        const inputs = questionsContainer.querySelectorAll('input[type="text"], textarea');
        for (const input of inputs) {
            const id = input.id || '';
            let val = '';
            if (id.includes('availability_to_start')) {
                val = 'Tenho disponibilidade imediata para começar.';
            } else if (id.includes('delivery_time_needed')) {
                val = typeof data.duration === 'number' ? `${data.duration} dias` : (data.duration || 'A combinar');
            } else if (id.includes('experience_on_this_type_of_projects')) {
                val = data.message.length > 250 ? data.message.substring(0, 247) + '...' : data.message;
            } else if (id.includes('data_needed_to_start')) {
                val = 'Requisitos funcionais detalhados, mockups/arquivos de design e acesso ao repositório se aplicável.';
            } else if (id.includes('chosen_one_reason')) {
                val = 'Tenho as competências técnicas exatas para o projeto, foco em qualidade e facilidade de comunicação.';
            } else {
                val = 'Estou disponível para alinhar e detalhar no chat.';
            }
            input.value = val;
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }

    // 2. Preencher Valor Total (Amount)
    const inputAmount = document.getElementById('Amount');
    if (inputAmount) {
        inputAmount.value = data.price;
        inputAmount.dispatchEvent(new Event('input', { bubbles: true }));
        inputAmount.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // 3. Preencher Duração (Tempo de entrega)
    const inputDelivery = document.getElementById('BidDeliveryTime');
    if (inputDelivery) {
        const durationText = typeof data.duration === 'number' ? `${data.duration} dias` : data.duration;
        inputDelivery.value = durationText;
        inputDelivery.dispatchEvent(new Event('input', { bubbles: true }));
        inputDelivery.dispatchEvent(new Event('change', { bubbles: true }));
    }
}

// Preenchimento de formulário para 99freelas
function fillProposalForm99freelas(data) {
    // Data: { message, price, duration }

    // 1. Preencher Textarea da Proposta
    const txtProposta = document.getElementById('proposta');
    if (txtProposta) {
        txtProposta.value = data.message;
        txtProposta.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // 2. Preencher Inputs de Valor (Prioridade para Oferta Final)
    const inputOfertaFinal = document.getElementById('oferta-final');
    const inputOferta = document.getElementById('oferta');

    if (inputOfertaFinal) {
        // Preenche o valor que o freelancer deseja receber (Exato conforme IA)
        inputOfertaFinal.value = formatCurrencyBR(data.price);
        inputOfertaFinal.dispatchEvent(new Event('input', { bubbles: true }));
        inputOfertaFinal.dispatchEvent(new Event('change', { bubbles: true }));
        
        // Dispara blur para garantir que o 99freelas processe o valor
        setTimeout(() => inputOfertaFinal.dispatchEvent(new Event('blur', { bubbles: true })), 100);
        
        console.log('[Auto-Proposal] Preenchendo Oferta Final:', data.price);
    } else if (inputOferta) {
        // Fallback caso o seletor mude ou não exista oferta-final
        inputOferta.value = formatCurrencyBR(data.price);
        inputOferta.dispatchEvent(new Event('input', { bubbles: true }));
        inputOferta.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // 3. Preencher Duração
    const inputDuracao = document.getElementById('duracao-estimada');
    if (inputDuracao) {
        inputDuracao.value = data.duration;
        inputDuracao.dispatchEvent(new Event('input', { bubbles: true }));
        inputDuracao.dispatchEvent(new Event('change', { bubbles: true }));
    }
}

// Preenchimento de formulário para Freelancer.com
function fillProposalFormFreelancer(data) {
    // Data: { message, price, duration }

    console.log('[Auto-Proposal] Preenchendo formulário Freelancer:', data);

    // 1. Preencher Textarea da Proposta (descrição)
    const txtDescription = document.getElementById('descriptionTextArea');
    if (txtDescription) {
        txtDescription.value = data.message;
        txtDescription.dispatchEvent(new Event('input', { bubbles: true }));
        txtDescription.dispatchEvent(new Event('change', { bubbles: true }));
        // Angular às vezes precisa de blur para detectar mudanças
        txtDescription.dispatchEvent(new Event('blur', { bubbles: true }));
    } else {
        console.warn('[Auto-Proposal] Campo descriptionTextArea não encontrado');
    }

    // 2. Preencher Bid Amount (valor)
    const inputBidAmount = document.getElementById('bidAmountInput');
    if (inputBidAmount) {
        // Freelancer usa valores numéricos diretos (sem formatação BR)
        inputBidAmount.value = data.price;
        inputBidAmount.dispatchEvent(new Event('input', { bubbles: true }));
        inputBidAmount.dispatchEvent(new Event('change', { bubbles: true }));
        inputBidAmount.dispatchEvent(new Event('blur', { bubbles: true }));
    } else {
        console.warn('[Auto-Proposal] Campo bidAmountInput não encontrado');
    }

    // 3. Preencher Period (dias)
    const inputPeriod = document.getElementById('periodInput');
    if (inputPeriod) {
        inputPeriod.value = data.duration;
        inputPeriod.dispatchEvent(new Event('input', { bubbles: true }));
        inputPeriod.dispatchEvent(new Event('change', { bubbles: true }));
        inputPeriod.dispatchEvent(new Event('blur', { bubbles: true }));
    } else {
        console.warn('[Auto-Proposal] Campo periodInput não encontrado');
    }
}

function runProposalGeneration() {
    // Validação de URL (aceita 99freelas, Freelancer.com e Workana)
    const isBidPage99freelas = window.location.href.includes("/project/bid/");
    const isBidPageFreelancer = CURRENT_SITE === 'freelancer' && window.location.href.includes("/projects/");
    const isBidPageWorkana = CURRENT_SITE === 'workana' && window.location.href.includes("/messages/bid/");

    if (!isBidPage99freelas && !isBidPageFreelancer && !isBidPageWorkana) {
        showToast("❌ Funcionalidade disponível apenas na página de enviar proposta.");
        return;
    }

    // Verificar se tem alguma API Key configurada ou se usa Backend
    const hasGemini = (STATE.settings.geminiKeys && STATE.settings.geminiKeys.length > 0) || (STATE.settings.apiKey && STATE.settings.apiKey.trim().length > 0);
    const hasGroq = (STATE.settings.groqKeys && STATE.settings.groqKeys.length > 0) || (STATE.settings.groqApiKey && STATE.settings.groqApiKey.trim().length > 0);
    const hasOpenAI = STATE.settings.openaiKeys && STATE.settings.openaiKeys.length > 0;
    const hasClaude = STATE.settings.claudeKeys && STATE.settings.claudeKeys.length > 0;
    const isBackendEnabled = STATE.settings.useBackend && STATE.settings.apiUrl;

    if (!hasGemini && !hasGroq && !hasOpenAI && !hasClaude && !isBackendEnabled) {
        showToast("⚠️ Configure ao menos uma API Key ou ative o Backend.");
        openSettings();
        return;
    }

    showToast("Gerando proposta...", "loading");

    // Coleta dados
    const context = scrapeProposalContext();
    
    // Envia a descrição COMPLETA do projeto conforme solicitado (sem cortes de tokens)
    const truncatedDescription = context.description;

    // Monta Prompt (inclui moeda se disponível)
    const currencyInfo = context.currency ? `\n    Moeda: ${context.currency}` : '';
    const activePrompt = STATE.settings[`proposalPrompt_${CURRENT_SITE}`] || STATE.settings.proposalPrompt || '';
    const activeProfile = STATE.settings[`userProfile_${CURRENT_SITE}`] || STATE.settings.userProfile || '';

    const userPrompt = `
    DADOS DO PROJETO:
    Cliente/Projeto: ${context.clientName}
    Descrição: ${truncatedDescription}
    Orçamento/Budget: ${context.avgValue}${currencyInfo}
    Prazo Médio: ${context.avgTime}

    MEU PROMPT DE PROPOSTA:
    ${activePrompt}

    IMPORTANTE:
    - O campo "message" deve ser uma proposta COMPLETA, PROFISSIONAL e EXTENSA (2000-2500 caracteres).
    - Use quebras de linha double-n (\\\\n\\\\n) para separar parágrafos e listas.
    - O campo "price" deve ser o valor TOTAL (Bruto) sugerido para o cliente pagar.
    - O preço deve ser sugerido na moeda ${context.currency || 'do projeto'}.
    - Retorne apenas o valor numérico inteiro no campo "price".

    Gere o JSON estrito com a mensagem longa e formatada, preço total sugerido e prazo em dias.
    `;

    const systemInstruction = `${PROPOSAL_SYSTEM_INSTRUCTION}\nMEU PERFIL: ${activeProfile}`;

    // Chama API (Suporta fallback global Gemini -> OpenAI -> Claude -> Groq)
    chrome.runtime.sendMessage({
        action: "aiRequest",
        taskType: "GENERATE_PROPOSAL",
        userId: STATE.user?.id,
        userName: STATE.user?.name,
        preferredProvider: STATE.settings.preferredProvider,
        apiUrl: STATE.settings.apiUrl,
        useBackend: STATE.settings.useBackend,
        platform: CURRENT_SITE,
        proposalData: {
            title: context.clientName,
            description: truncatedDescription,
            value: context.avgValue,
            currency: context.currency
        },
        geminiKeys: STATE.settings.geminiKeys || (STATE.settings.apiKey ? [STATE.settings.apiKey] : []),
        groqKeys: STATE.settings.groqKeys || (STATE.settings.groqApiKey ? [STATE.settings.groqApiKey] : []),
        openaiKeys: STATE.settings.openaiKeys,
        claudeKeys: STATE.settings.claudeKeys,
        openaiModel: STATE.settings.openaiModel,
        claudeModel: STATE.settings.claudeModel,
        groqModel: STATE.settings.groqModel,
        systemInstruction: systemInstruction,
        userPrompt: userPrompt
    }, (response) => {
        if (!response || !response.success) {
            console.error("[Auto-Proposal] Error:", response?.error);
            showToast("❌ Erro ao gerar proposta.");
            return;
        }

        if (response.source) {
            console.log(`%c[Auto-Proposal] Proposta gerada com sucesso via ${response.source}`, "color: #4CAF50; font-weight: bold;");
        }

        let data = response.data; // Pode vir como String ou Objeto

        // --- DEBUG LOGGING ---
        console.group("[Auto-Proposal Debug]");
        console.log("Raw Response Type:", typeof data);
        console.log("Raw Response Content:", data);
        console.groupEnd();
        // ---------------------

        // SAFETY PARSER: Se for string, limpa Markdown e faz parse
        if (typeof data === 'string') {
            try {
                console.log("[Auto-Proposal] Cleaning Markdown from String...");
                // Remove ```json e ``` (e possíveis espaços extras)
                const cleanText = data.replace(/```json\s*/i, '').replace(/```/g, '').trim();
                data = JSON.parse(cleanText);
                console.log("[Auto-Proposal] Parsed JSON:", data);
            } catch (e) {
                console.error("[Auto-Proposal] Failed to parse JSON string:", e);
                showToast("❌ Erro ao processar resposta da IA.");
                return;
            }
        }

        // Sanitização (Tenta converter string para numero se a IA mandou "15 dias")
        const cleanPrice = sanitizeNumber(data.price);
        const cleanDuration = sanitizeNumber(data.duration);

        if (data.message && (cleanPrice || cleanPrice === 0) && (cleanDuration || cleanDuration === 0)) {
            fillProposalForm({
                message: data.message,
                price: cleanPrice,
                duration: cleanDuration
            });
            showToast("✅ Proposta preenchida!");

            // RADAR: se esta aba foi aberta pelo Radar, envia sozinho e fecha
            if (STATE.radarAutoSubmit) {
                const currentSite = CURRENT_SITE;
                STATE.radarAutoSubmit = false;
                setTimeout(async () => {
                    showToast("🚀 Radar: enviando proposta...", "loading");
                    let ok = false;
                    if (currentSite === 'workana') {
                        ok = await submitProposalWorkana();
                    } else {
                        ok = await submitProposal99freelas();
                    }
                    showToast(ok ? "✅ Radar: proposta enviada!" : "❌ Radar: falha ao enviar.");
                    setTimeout(radarAdvance, 2000); // avança a fila (background navega a aba worker)
                }, 900);
            }
        } else {
            console.warn("[Auto-Proposal] Validation Failed. Missing keys or invalid types.", data);
            showToast("⚠️ Resposta da IA incompleta. Veja o Console.");
        }
    });
}

// -----------------------------------------------------------------------------
// 6.5. BOTÕES DE DISPARO RÁPIDO (PÁGINA DE MENSAGENS — 99FREELAS)
// -----------------------------------------------------------------------------

const AP_QUICK_COLORS = ['#0A84FF', '#30D158', '#FF9F0A', '#FF453A', '#BF5AF2', '#64D2FF', '#FFD60A', '#8E8E93'];

// --- Helper genérico: aguarda uma condição no DOM (com timeout) ---
function apWaitFor(checkFn, timeout = 1800, interval = 60) {
    return new Promise((resolve) => {
        const start = Date.now();
        const tick = () => {
            let el = null;
            try { el = checkFn(); } catch (e) { el = null; }
            if (el) return resolve(el);
            if (Date.now() - start >= timeout) return resolve(null);
            setTimeout(tick, interval);
        };
        tick();
    });
}

// --- Lê as etiquetas existentes da conta direto do DOM da página ---
function getPageTags() {
    const tags = [];
    document.querySelectorAll('.container-tags .list-tags li.tag-item').forEach(li => {
        if (li.classList.contains('model')) return; // ignora o template
        const id = li.getAttribute('data-id');
        if (!id) return;
        const nameInput = li.querySelector('.nome-tag-value');
        const name = (nameInput ? nameInput.value : (li.getAttribute('title') || '')).trim();
        const colorInput = li.querySelector('.classe-cor-tag-value');
        const colorClass = colorInput ? colorInput.value : '';
        tags.push({ id, name, colorClass });
    });
    return tags;
}

// --- Identifica a área de envio visível (a conversa aberta) ---
function getVisibleSendContainer() {
    const containers = Array.from(document.querySelectorAll('.send-message-container'));
    return containers.find(c => c.offsetParent !== null && c.querySelector('.send-message-textarea')) || null;
}

// --- Identifica a conversa ativa na lista ---
function getActiveConversation() {
    return document.querySelector('li.conversa-item.active')
        || document.querySelector('li.conversa-item.selected')
        || null;
}

// --- Preenche o textarea e clica em Enviar ---
function apSendMessage(container, text) {
    const textarea = container.querySelector('.send-message-textarea');
    if (!textarea) { showToast('❌ Campo de mensagem não encontrado.'); return false; }

    textarea.focus();
    // Usa o setter nativo para garantir que frameworks detectem a mudança
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
    nativeSetter.call(textarea, text);
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    textarea.dispatchEvent(new Event('change', { bubbles: true }));
    textarea.dispatchEvent(new Event('keyup', { bubbles: true }));

    const sendBtn = container.querySelector('.btn-enviar-texto');
    if (!sendBtn) { showToast('❌ Botão "Enviar" não encontrado.'); return false; }
    sendBtn.click();
    return true;
}

// --- Aplica uma etiqueta à conversa ativa simulando o menu nativo ---
async function apApplyTag(tagId, tagName) {
    const conv = getActiveConversation();
    if (!conv) { showToast('⚠️ Conversa ativa não encontrada (etiqueta não aplicada).'); return false; }

    const optBtn = conv.querySelector('.box-action.item-options-container')
        || conv.querySelector('.box-action')
        || conv.querySelector('.icon-options');
    if (!optBtn) { showToast('⚠️ Menu de opções da conversa não encontrado.'); return false; }

    optBtn.click();

    // Aguarda o menu de ações abrir
    const menu = await apWaitFor(() => {
        const m = document.querySelector('.float-box-conversa-options');
        return (m && m.offsetParent !== null) ? m : null;
    });
    if (!menu) { showToast('⚠️ Menu de etiquetas não abriu a tempo.'); return false; }

    const addEtiqueta = menu.querySelector('.btn-adicionar-etiqueta');
    if (!addEtiqueta) { showToast('⚠️ Opção "Adicionar etiqueta" indisponível.'); document.body.click(); return false; }
    addEtiqueta.click();

    // Aguarda o submenu de tags e a opção desejada
    const tagOpt = await apWaitFor(() => {
        const box = menu.querySelector('.float-box-tags');
        if (!box || box.offsetParent === null) return null;
        let el = box.querySelector(`.add-tag[data-id="${tagId}"]:not(.model)`);
        if (!el && tagName) {
            el = Array.from(box.querySelectorAll('.add-tag:not(.model)')).find(o => {
                const t = o.querySelector('.text.main');
                return t && t.textContent.trim() === tagName.trim();
            });
        }
        return el || null;
    });

    if (!tagOpt) {
        // Provavelmente a etiqueta já estava aplicada — fecha o menu sem erro
        document.body.click();
        return false;
    }

    tagOpt.click();
    setTimeout(() => document.body.click(), 200); // fecha resíduos do menu
    return true;
}

// --- Dispara um botão rápido: envia a mensagem e (opcional) aplica a tag ---
async function triggerQuickButton(btn, sourceContainer) {
    if (!btn) return;
    const container = sourceContainer || getVisibleSendContainer();
    if (!container) { showToast('❌ Abra uma conversa para disparar a mensagem.'); return; }

    STATE.lastQuickId = btn.id;

    const sent = apSendMessage(container, btn.message);
    if (!sent) return;
    showToast('📨 Mensagem enviada!');

    if (btn.tagId) {
        setTimeout(async () => {
            const ok = await apApplyTag(btn.tagId, btn.tagName);
            if (ok) showToast(`🏷️ Etiqueta "${btn.tagName}" aplicada.`);
        }, 300);
    }
}

// --- Storage local por usuário ---
function quickStorageKey() {
    const uid = STATE.user ? (STATE.user.id || STATE.user.email) : 'anon';
    return `ap_quick_buttons_${uid}`;
}

function loadQuickButtons(cb) {
    if (!STATE.user) {
        STATE.quickButtons = [];
        renderAllQuickBars();
        if (cb) cb();
        return;
    }
    const key = quickStorageKey();
    chrome.storage.local.get([key], (res) => {
        STATE.quickButtons = Array.isArray(res[key]) ? res[key] : [];
        renderAllQuickBars();
        if (cb) cb();
    });
}

function saveQuickButtons(cb) {
    const key = quickStorageKey();
    chrome.storage.local.set({ [key]: STATE.quickButtons }, () => {
        renderAllQuickBars();
        if (cb) cb();
    });
}

// --- Injeção da barra de botões na(s) área(s) de envio ---
function injectQuickBars() {
    if (CURRENT_SITE !== '99freelas' || !STATE.user) return;
    document.querySelectorAll('.send-message-options-container').forEach(c => {
        if (c.querySelector('.ap-quick-bar')) return;
        const bar = document.createElement('div');
        bar.className = 'ap-quick-bar';
        c.insertBefore(bar, c.firstChild);
        renderQuickBar(bar);
    });
}

function renderQuickBar(bar) {
    bar.innerHTML = '';
    if (!STATE.quickButtons || STATE.quickButtons.length === 0) {
        bar.classList.add('ap-empty');
        return;
    }
    bar.classList.remove('ap-empty');
    STATE.quickButtons.forEach(btn => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'ap-quick-btn';
        b.title = btn.message
            + (btn.tagName ? `\n🏷️ ${btn.tagName}` : '')
            + (btn.shortcut ? `\n⌨️ ${btn.shortcut.modifier} + ${btn.shortcut.key}` : '');
        b.textContent = btn.label || '(sem nome)';
        if (btn.color) b.style.setProperty('--ap-qb-color', btn.color);
        if (btn.tagName) b.classList.add('has-tag');
        b.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            triggerQuickButton(btn, b.closest('.send-message-container'));
        });
        bar.appendChild(b);
    });
}

function renderAllQuickBars() {
    injectQuickBars();
    document.querySelectorAll('.ap-quick-bar').forEach(renderQuickBar);
}

let apQuickObserver = null;
function startQuickBarObserver() {
    if (CURRENT_SITE !== '99freelas') return;
    injectQuickBars();
    if (apQuickObserver) return;
    let scheduled = false;
    apQuickObserver = new MutationObserver(() => {
        if (scheduled || document.hidden) return; // não processa mutações com a aba em segundo plano
        scheduled = true;
        setTimeout(() => { scheduled = false; injectQuickBars(); }, 700);
    });
    apQuickObserver.observe(document.body, { childList: true, subtree: true });
    // Ao voltar do segundo plano, garante que as barras estão presentes
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) injectQuickBars();
    });
}

// --- UI de configuração (dentro do modal de Configurações) ---
let apEditingId = null;
let apEditorShortcut = null; // Atalho sendo editado no momento

function updateQuickShortcutLabel() {
    const btn = document.getElementById('ap-quick-shortcut');
    if (!btn) return;
    btn.innerText = apEditorShortcut ? `${apEditorShortcut.modifier} + ${apEditorShortcut.key}` : 'Definir';
}

function recordQuickShortcut(btnElement) {
    const original = btnElement.innerText;
    btnElement.innerText = 'Detectando...';
    btnElement.classList.add('recording');

    function handleKey(e) {
        e.preventDefault();
        e.stopPropagation();
        if (['Shift', 'Control', 'Alt', 'Meta', 'Command'].includes(e.key)) return;

        let modifier = '';
        if (e.shiftKey) modifier = 'Shift';
        else if (e.ctrlKey) modifier = 'Ctrl';
        else if (e.altKey) modifier = 'Alt';
        else if (e.metaKey) modifier = 'Cmd';

        if (modifier && e.key) {
            apEditorShortcut = { modifier, key: e.key.toUpperCase() };
            updateQuickShortcutLabel();
            cleanup();
        }
    }

    function cleanup() {
        btnElement.classList.remove('recording');
        document.removeEventListener('keydown', handleKey, true);
        document.removeEventListener('click', cancelClick, true);
    }

    function cancelClick(e) {
        if (e.target !== btnElement) {
            updateQuickShortcutLabel();
            cleanup();
        }
    }

    document.addEventListener('keydown', handleKey, true);
    setTimeout(() => document.addEventListener('click', cancelClick, true), 100);
}

function renderQuickButtonsConfig() {
    const list = document.getElementById('ap-quick-list');
    if (!list) return;
    list.innerHTML = '';

    if (!STATE.user) {
        list.innerHTML = '<div class="ap-quick-empty">Faça login para configurar os botões.</div>';
        return;
    }
    if (!STATE.quickButtons || STATE.quickButtons.length === 0) {
        list.innerHTML = '<div class="ap-quick-empty">Nenhum botão criado ainda.</div>';
        return;
    }

    STATE.quickButtons.forEach((btn, idx) => {
        const row = document.createElement('div');
        row.className = 'ap-quick-row';
        const dot = btn.color ? `<span class="ap-quick-dot" style="background:${btn.color}"></span>` : '';
        const tag = btn.tagName ? `<span class="ap-quick-tagchip">🏷️ ${btn.tagName}</span>` : '';
        const sc = btn.shortcut ? `<span class="ap-quick-tagchip">⌨️ ${btn.shortcut.modifier}+${btn.shortcut.key}</span>` : '';
        row.innerHTML = `
            <div class="ap-quick-row-main">${dot}<span class="ap-quick-row-label">${btn.label || '(sem nome)'}</span>${tag}${sc}</div>
            <div class="ap-quick-row-actions">
                <button type="button" data-act="up" title="Subir" ${idx === 0 ? 'disabled' : ''}>▲</button>
                <button type="button" data-act="down" title="Descer" ${idx === STATE.quickButtons.length - 1 ? 'disabled' : ''}>▼</button>
                <button type="button" data-act="edit" title="Editar">✎</button>
                <button type="button" data-act="del" title="Remover">✕</button>
            </div>`;
        row.querySelector('[data-act="up"]').addEventListener('click', () => moveQuickButton(idx, -1));
        row.querySelector('[data-act="down"]').addEventListener('click', () => moveQuickButton(idx, 1));
        row.querySelector('[data-act="edit"]').addEventListener('click', () => openQuickEditor(btn));
        row.querySelector('[data-act="del"]').addEventListener('click', () => removeQuickButton(btn.id));
        list.appendChild(row);
    });
}

function populateQuickTagSelect(selectedId) {
    const sel = document.getElementById('ap-quick-tag');
    const note = document.getElementById('ap-quick-tag-note');
    if (!sel) return;
    const tags = getPageTags();
    sel.innerHTML = '<option value="">(sem etiqueta)</option>';
    tags.forEach(t => {
        const o = document.createElement('option');
        o.value = t.id;
        o.textContent = t.name;
        o.dataset.name = t.name;
        if (t.id === selectedId) o.selected = true;
        sel.appendChild(o);
    });
    // Mantém a tag atual mesmo se a página de mensagens não estiver aberta
    if (selectedId && !tags.find(t => t.id === selectedId)) {
        const editing = STATE.quickButtons.find(b => b.id === apEditingId);
        const o = document.createElement('option');
        o.value = selectedId;
        o.textContent = (editing && editing.tagName) ? `${editing.tagName} (atual)` : selectedId;
        o.dataset.name = editing ? (editing.tagName || '') : '';
        o.selected = true;
        sel.appendChild(o);
    }
    if (note) note.style.display = tags.length ? 'none' : 'block';
}

function renderQuickColors(selected) {
    const wrap = document.getElementById('ap-quick-colors');
    if (!wrap) return;
    wrap.innerHTML = '';
    wrap.dataset.selected = selected || AP_QUICK_COLORS[0];
    AP_QUICK_COLORS.forEach(c => {
        const sw = document.createElement('span');
        sw.className = 'ap-color-sw' + (c === wrap.dataset.selected ? ' selected' : '');
        sw.style.background = c;
        sw.addEventListener('click', () => {
            wrap.dataset.selected = c;
            wrap.querySelectorAll('.ap-color-sw').forEach(s => s.classList.remove('selected'));
            sw.classList.add('selected');
        });
        wrap.appendChild(sw);
    });
}

function openQuickEditor(btn) {
    const editor = document.getElementById('ap-quick-editor');
    if (!editor) return;
    apEditingId = btn ? btn.id : null;
    document.getElementById('ap-quick-label').value = btn ? (btn.label || '') : '';
    document.getElementById('ap-quick-message').value = btn ? (btn.message || '') : '';
    populateQuickTagSelect(btn ? btn.tagId : '');
    renderQuickColors(btn ? btn.color : AP_QUICK_COLORS[0]);
    apEditorShortcut = btn && btn.shortcut ? btn.shortcut : null;
    updateQuickShortcutLabel();
    editor.classList.remove('ap-hidden');
    editor.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function closeQuickEditor() {
    const editor = document.getElementById('ap-quick-editor');
    if (editor) editor.classList.add('ap-hidden');
    apEditingId = null;
}

function saveQuickFromEditor() {
    const label = document.getElementById('ap-quick-label').value.trim();
    const message = document.getElementById('ap-quick-message').value.trim();
    const sel = document.getElementById('ap-quick-tag');
    const tagId = sel.value || '';
    const tagName = tagId ? (sel.options[sel.selectedIndex].dataset.name || sel.options[sel.selectedIndex].textContent) : '';
    const color = document.getElementById('ap-quick-colors').dataset.selected || AP_QUICK_COLORS[0];

    if (!label) { showToast('⚠️ Dê um nome ao botão.'); return; }
    if (!message) { showToast('⚠️ Escreva a mensagem.'); return; }

    const shortcut = apEditorShortcut || null;

    if (apEditingId) {
        const b = STATE.quickButtons.find(x => x.id === apEditingId);
        if (b) { b.label = label; b.message = message; b.tagId = tagId; b.tagName = tagName; b.color = color; b.shortcut = shortcut; }
    } else {
        STATE.quickButtons.push({
            id: 'qb_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
            label, message, tagId, tagName, color, shortcut
        });
    }

    saveQuickButtons(() => {
        renderQuickButtonsConfig();
        closeQuickEditor();
        showToast('✅ Botão salvo.');
    });
}

function removeQuickButton(id) {
    STATE.quickButtons = STATE.quickButtons.filter(b => b.id !== id);
    if (apEditingId === id) closeQuickEditor();
    saveQuickButtons(() => renderQuickButtonsConfig());
}

function moveQuickButton(idx, dir) {
    const target = idx + dir;
    if (target < 0 || target >= STATE.quickButtons.length) return;
    const arr = STATE.quickButtons;
    [arr[idx], arr[target]] = [arr[target], arr[idx]];
    saveQuickButtons(() => renderQuickButtonsConfig());
}

// -----------------------------------------------------------------------------
// 7. INICIALIZAÇÃO & LISTENERS
// -----------------------------------------------------------------------------

// =============================================================================
// RADAR (AUTO-BID) — vigia projetos novos e envia a proposta sozinho
// =============================================================================

const AP_RADAR_KEYS = {
    on: `ap_radar_on_${CURRENT_SITE}`,
    interval: `ap_radar_interval_${CURRENT_SITE}`,
    kw: `ap_radar_keywords_${CURRENT_SITE}`,
    seen: `ap_radar_seen_${CURRENT_SITE}`
};

// Envia a proposta no 99freelas (clica "Enviar proposta" + confirma o modal). Retorna true/false.
async function submitProposal99freelas() {
    const sendBtn = document.getElementById('btnConcluirEnvioProposta');
    if (!sendBtn) { console.warn('[Radar] Botão "Enviar proposta" não encontrado.'); return false; }
    sendBtn.click();

    // Aguarda eventual modal de confirmação e confirma
    const modal = await apWaitFor(() => {
        const cands = [
            document.querySelector('.modal-confirmacao-proposta-pergunta'),
            document.querySelector('.modal-padrao-suspeito-mensagem')
        ];
        for (const m of cands) {
            if (m && m.offsetParent !== null) return m; // visível
        }
        return null;
    }, 3000, 120);

    if (modal) {
        const chk = modal.querySelector('input.confirm-action[type="checkbox"], input[type="checkbox"]');
        if (chk && !chk.checked) {
            chk.checked = true;
            chk.dispatchEvent(new Event('change', { bubbles: true }));
        }
        await new Promise(r => setTimeout(r, 250));
        const go = modal.querySelector('.btn-acao');
        if (go) go.click();
        await new Promise(r => setTimeout(r, 600));
    }
    return true;
}

// Envia a proposta no Workana (clica "Enviar orçamento" + confirma se houver modal). Retorna true/false.
async function submitProposalWorkana() {
    const sendBtn = document.querySelector('#bidForm input[type="submit"], #bidForm button[type="submit"], .wk-submit-block input[type="submit"], .wk-submit-block button[type="submit"]');
    if (!sendBtn) { console.warn('[Radar] Botão "Enviar orçamento" não encontrado.'); return false; }
    sendBtn.click();

    // Aguarda eventual modal de confirmação (ex: para projeto por hora)
    const modal = await apWaitFor(() => {
        const m = document.querySelector('.wk-dialog, .modal.fade.in');
        if (m && m.offsetParent !== null) return m; // visível
        return null;
    }, 3000, 120);

    if (modal) {
        // Clica no botão primário dentro do rodapé do modal (independe de idioma)
        const confirmBtn = modal.querySelector('.modal-footer .btn-primary, .modal-footer button.btn-primary, button.btn-primary');
        if (confirmBtn) {
            confirmBtn.click();
        }
        await new Promise(r => setTimeout(r, 600));
    }
    return true;
}

function radarMatchesFilter(title, desc, kw) {
    if (!kw) return true;
    const terms = kw.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
    if (!terms.length) return true;
    const hay = (title + ' ' + desc).toLowerCase();
    return terms.some(t => hay.includes(t));
}

function radarBidBase(projectUrl) {
    let u = projectUrl.split('?')[0].split('#')[0];
    if (CURRENT_SITE === 'workana') {
        const pathParts = window.location.pathname.split('/');
        let langPrefix = '';
        if (pathParts[1] && pathParts[1].length === 2) {
            langPrefix = '/' + pathParts[1];
        }
        
        let path = u;
        if (u.startsWith('http')) {
            try {
                const urlObj = new URL(u);
                path = urlObj.pathname;
                // Remove prefixo de idioma preexistente para padronizar
                path = path.replace(/^\/(en|es|pt)\//, '/');
            } catch (e) {}
        }
        if (!path.startsWith('/')) path = '/' + path;
        u = window.location.origin + langPrefix + path;
    } else {
        if (!u.startsWith('http')) {
            u = 'https://www.99freelas.com.br' + u;
        }
    }

    if (CURRENT_SITE === 'workana') {
        return u.replace('/job/', '/messages/bid/');
    }
    return u.replace('/project/', '/project/bid/');
}
function radarSetStatus(txt) {
    const el = document.getElementById('ap-radar-status');
    if (el) el.textContent = txt;
}

// Worker: avança a fila (uma única vez por carregamento da aba)
function radarAdvance() {
    if (STATE.radarNextSent) return;
    STATE.radarNextSent = true;
    chrome.runtime.sendMessage({ action: 'radarNext' });
}

// Coleta TODOS os projetos sem proposta e adiciona à fila (no background)
// Trava de concorrência: evita fetch + DOMParser sobrepostos (grande causa de travamento)
async function radarCollectAndEnqueue() {
    if (STATE.radarCollecting) return; // já tem uma varredura rodando → ignora
    STATE.radarCollecting = true;
    try {
        // Carrega palavras-chave do storage local do Radar para filtrar os projetos antes de enfileirar
        const storageData = await new Promise(resolve => {
            chrome.storage.local.get([AP_RADAR_KEYS.kw], (res) => resolve(res || {}));
        });
        const keywords = storageData[AP_RADAR_KEYS.kw] || '';
        
        const pendentes = [];
        if (CURRENT_SITE === 'workana') {
            let html;
            try {
                const pathParts = window.location.pathname.split('/');
                let langPrefix = '';
                if (pathParts[1] && pathParts[1].length === 2) {
                    langPrefix = '/' + pathParts[1];
                }
                const searchUrl = langPrefix + '/jobs?category=it-programming&language=en%2Cpt&subcategory=web-development%2Cweb-design%2Ce-commerce%2Cwordpress-1%2Cmobile-development%2Cdata-science-1%2Cdesktop-apps%2Cartificial-intelligence-1%2Cothers-5';
                console.log('[Radar Workana] Fazendo fetch da URL de busca filtrada (desenvolvimento):', searchUrl);
                const resp = await fetch(searchUrl, { credentials: 'include' });
                html = await resp.text();
            } catch (e) {
                console.warn('[Radar Workana] Falha no fetch da busca filtrada. Tentando ler do DOM ativo como fallback...', e);
                if (window.location.pathname.includes('/jobs')) {
                    const items = document.querySelectorAll('.project-item, .job-item');
                    for (const el of items) {
                        const alreadyBid = el.querySelector('.bid, .wk2-icon-messages-b') || 
                                           el.textContent.includes('Ir para as mensagens') ||
                                           el.innerHTML.includes('/messages/index/');
                        if (alreadyBid) continue;

                        const titleEl = el.querySelector('.project-title a, h2 a, h2.title a');
                        const link = titleEl ? titleEl.getAttribute('href') : '';
                        
                        const title = titleEl ? titleEl.textContent : '';
                        const descEl = el.querySelector('.project-description, .description, p');
                        const desc = descEl ? descEl.textContent : '';
                        if (!radarMatchesFilter(title, desc, keywords)) continue;

                        if (link) {
                            pendentes.push(radarBidBase(link));
                        }
                    }
                    console.log(`[Radar Workana] Fallback DOM Concluído: ${items.length} analisados | ${pendentes.length} pendentes.`);
                    if (pendentes.length) {
                        chrome.runtime.sendMessage({ action: 'radarEnqueue', urls: pendentes }, (resp) => {
                            const total = (resp && resp.queued != null) ? resp.queued : '?';
                            const added = (resp && resp.added != null) ? resp.added : '?';
                            radarSetStatus('📡 Radar: fila ' + total + ' (+' + added + ' novos).');
                        });
                    } else {
                        radarSetStatus('📡 Radar ativo (fallback DOM). Nenhum projeto sem proposta.');
                    }
                }
                return;
            }

            const doc = new DOMParser().parseFromString(html, 'text/html');
            const items = doc.querySelectorAll('.project-item, .job-item');
            for (const el of items) {
                // Se já estiver "Em contato" ou tiver o botão de "Ir para as mensagens", ignora
                // textContent é compatível com DOMParser (innerText exige renderização física e retorna vazio)
                const alreadyBid = el.querySelector('.bid, .wk2-icon-messages-b') || 
                                   el.textContent.includes('Ir para as mensagens') ||
                                   el.innerHTML.includes('/messages/index/');
                if (alreadyBid) continue;

                const titleEl = el.querySelector('.project-title a, h2 a, h2.title a');
                const link = titleEl ? titleEl.getAttribute('href') : '';
                
                // Filtro de palavras-chave
                const title = titleEl ? titleEl.textContent : '';
                const descEl = el.querySelector('.project-description, .description, p');
                const desc = descEl ? descEl.textContent : '';
                if (!radarMatchesFilter(title, desc, keywords)) {
                    console.log(`[Radar Workana] Projeto ignorado pelo filtro: "${title}"`);
                    continue;
                }

                if (link) {
                    pendentes.push(radarBidBase(link));
                }
            }
            console.log(`[Radar Workana] Varredura Concluída: ${items.length} analisados | ${pendentes.length} pendentes (sem proposta e validados pelo filtro).`);
        } else {
            // 99freelas
            let html;
            try {
                const resp = await fetch('/project-notifications/view?limit=50', { credentials: 'include' });
                html = await resp.text();
            } catch (e) { console.warn('[Radar] Falha no fetch:', e); return; }

            const doc = new DOMParser().parseFromString(html, 'text/html');
            const items = Array.from(doc.querySelectorAll('li.result-item[data-id]'));

            for (const li of items) {
                if (li.querySelector('.icon-proposal')) continue; // já enviei proposta
                const a = li.querySelector('.title a');
                const link = a ? a.getAttribute('href') : '';
                
                // Filtro de palavras-chave
                const title = a ? a.textContent : '';
                const descEl = li.querySelector('.description, .p-projetos-descricao');
                const desc = descEl ? descEl.textContent : '';
                if (!radarMatchesFilter(title, desc, keywords)) {
                    console.log(`[Radar 99freelas] Projeto ignorado pelo filtro: "${title}"`);
                    continue;
                }

                if (link) pendentes.push(radarBidBase(link));
            }
            console.log(`[Radar 99freelas] Varredura Concluída: ${items.length} analisados | ${pendentes.length} pendentes (sem proposta e validados pelo filtro).`);
        }

        if (pendentes.length) {
            chrome.runtime.sendMessage({ action: 'radarEnqueue', urls: pendentes }, (resp) => {
                const total = (resp && resp.queued != null) ? resp.queued : '?';
                const added = (resp && resp.added != null) ? resp.added : '?';
                console.log(`[Radar] Background: +${added} novos na fila (fila atual: ${total}).`);
                radarSetStatus('📡 Radar: fila ' + total + ' (+' + added + ' novos).');
            });
        } else {
            radarSetStatus('📡 Radar ativo. Nenhum projeto sem proposta no momento.');
        }
    } finally {
        STATE.radarCollecting = false;
    }
}

// Coalesce: rajadas de mudança no header viram UMA única coleta (debounce)
let radarCollectDebounce = null;
function radarCollectSoon() {
    if (radarCollectDebounce) return;
    radarCollectDebounce = setTimeout(() => {
        radarCollectDebounce = null;
        radarCollectAndEnqueue();
    }, 1500);
}

// Agenda o timer de recoleta, mais lento quando a aba está em segundo plano
function radarScheduleTimer() {
    if (STATE.radarTimer) { clearInterval(STATE.radarTimer); STATE.radarTimer = null; }
    const intervalEl = document.getElementById('ap-radar-interval');
    let secs = parseInt(intervalEl ? intervalEl.value : '12', 10);
    if (isNaN(secs) || secs < 6) secs = 12;
    if (document.hidden) secs = Math.max(secs * 4, 30); // background → polla bem mais devagar
    STATE.radarTimer = setInterval(radarCollectAndEnqueue, secs * 1000);
}

// Vigia o contador "Novos Projetos" do header; ao mudar → recoleta
function radarStartHeaderWatch() {
    radarStopHeaderWatch();
    const countEl = document.querySelector('.box-notificacao-projeto-count .count-value');
    if (countEl) {
        STATE.radarObserver = new MutationObserver(() => radarCollectSoon());
        STATE.radarObserver.observe(countEl, { childList: true, characterData: true, subtree: true });
    }
    // Fallback: recoleta periodicamente (dedup garante que não duplica)
    radarScheduleTimer();
    // Reajusta o ritmo quando a aba vai/volta do segundo plano
    if (!STATE.radarVisHooked) {
        STATE.radarVisHooked = true;
        document.addEventListener('visibilitychange', () => {
            if (STATE.radarTimer) radarScheduleTimer();
        });
    }
}
function radarStopHeaderWatch() {
    if (STATE.radarObserver) { try { STATE.radarObserver.disconnect(); } catch (e) {} STATE.radarObserver = null; }
    if (STATE.radarTimer) { clearInterval(STATE.radarTimer); STATE.radarTimer = null; }
    if (radarCollectDebounce) { clearTimeout(radarCollectDebounce); radarCollectDebounce = null; }
}

async function startRadar() {
    chrome.storage.local.remove(AP_RADAR_KEYS.seen); // limpa lixo das versões antigas
    radarSetStatus('📡 Montando fila de projetos sem proposta...');
    await radarCollectAndEnqueue(); // fila inicial (todos os pendentes)
    radarStartHeaderWatch();        // passa a vigiar o header + fallback
}

function stopRadar() {
    radarStopHeaderWatch();
    chrome.runtime.sendMessage({ action: 'radarStop' });
    radarSetStatus('Radar desligado.');
}

// Configura o Radar: handler da aba de bid + wiring da UI + auto-start
function setupRadar() {
    // 1) Esta aba é a página de bid aberta pelo Radar? → gera + envia + fecha
    const isRadarBidPage99freelas = CURRENT_SITE === '99freelas' && location.href.includes('/project/bid/');
    const isRadarBidPageWorkana = CURRENT_SITE === 'workana' && location.href.includes('/messages/bid/');

    if ((isRadarBidPage99freelas || isRadarBidPageWorkana)
        && location.hash.includes('ap-radar-send')) {
        STATE.radarAutoSubmit = true;
        STATE.radarNextSent = false;
        STATE.lastAutoRunUrl = location.href; // evita o Modo Automático duplicar
        // Se a página sair (após enviar, ela navega/recarrega), pede o próximo ANTES de morrer
        window.addEventListener('beforeunload', radarAdvance);
        window.addEventListener('pagehide', radarAdvance);
        // Watchdog local: se travar sem navegar (IA falhar), avança assim mesmo
        setTimeout(radarAdvance, 45000);
        
        apWaitFor(() => {
            const hasForm = CURRENT_SITE === 'workana'
                ? (document.getElementById('BidContent') || document.getElementById('projectQuestions') || document.getElementById('Amount'))
                : document.getElementById('proposta');
            return hasForm && STATE.settingsLoaded;
        }, 12000, 150).then(hasFormLoaded => {
            if (hasFormLoaded) {
                runProposalGeneration();
            } else {
                console.warn('[Radar] Form de bid não carregou; pulando para o próximo.');
                radarAdvance();
            }
        });
        return;
    }

    // 2) Wiring da UI (o modal de settings já está no DOM, mesmo fechado)
    const toggle = document.getElementById('ap-radar-toggle');
    const intervalEl = document.getElementById('ap-radar-interval');
    const kwEl = document.getElementById('ap-radar-keywords');

    chrome.storage.local.get([AP_RADAR_KEYS.on, AP_RADAR_KEYS.interval, AP_RADAR_KEYS.kw], (r) => {
        if (intervalEl && r[AP_RADAR_KEYS.interval]) intervalEl.value = r[AP_RADAR_KEYS.interval];
        if (kwEl && typeof r[AP_RADAR_KEYS.kw] === 'string') kwEl.value = r[AP_RADAR_KEYS.kw];
        if (toggle) toggle.checked = !!r[AP_RADAR_KEYS.on];
        if (r[AP_RADAR_KEYS.on]) startRadar(); // roda em qualquer página do 99freelas
    });

    if (toggle) toggle.addEventListener('change', () => {
        const on = toggle.checked;
        chrome.storage.local.set({ [AP_RADAR_KEYS.on]: on });
        if (on) { startRadar(); showToast('📡 Radar ligado! Disparando em projetos sem proposta.'); }
        else { stopRadar(); showToast('Radar desligado.'); }
    });

    const startBtn = document.getElementById('ap-radar-start');
    const stopBtn = document.getElementById('ap-radar-stop');
    if (startBtn) startBtn.addEventListener('click', () => {
        if (toggle) toggle.checked = true;
        chrome.storage.local.set({ [AP_RADAR_KEYS.on]: true });
        console.log('[Radar] Iniciado pelo botão.');
        startRadar();
        showToast('📡 Radar iniciado!');
    });
    if (stopBtn) stopBtn.addEventListener('click', () => {
        if (toggle) toggle.checked = false;
        chrome.storage.local.set({ [AP_RADAR_KEYS.on]: false });
        stopRadar();
        showToast('Radar parado.');
    });
    if (intervalEl) intervalEl.addEventListener('change', () => {
        chrome.storage.local.set({ [AP_RADAR_KEYS.interval]: intervalEl.value });
        if (STATE.radarTimer) startRadar();
    });
    if (kwEl) kwEl.addEventListener('change', () => {
        chrome.storage.local.set({ [AP_RADAR_KEYS.kw]: kwEl.value });
    });
}

// =============================================================================
// MONITOR DE MENSAGENS — vigia o contador de mensagens do 99freelas e avisa no WhatsApp
// =============================================================================

const AP_MSG_KEYS = {
    on: 'ap_msg_on',
    group: 'ap_msg_group',
    groupName: 'ap_msg_group_name',
    lastAt: 'ap_msg_last_notify_at',
    active: 'ap_msg_active',
    lastCount: 'ap_msg_last_count',
    num: 'ap_msg_notify_num'
};
const AP_MSG_RENOTIFY_MS = 5 * 60 * 1000; // reavisa a cada 5 minutos

function msgGetCount() {
    const el = document.querySelector('.box-mensagem-count .count-value');
    if (!el) return 0;
    const n = parseInt((el.textContent || '').trim(), 10);
    return isNaN(n) ? 0 : n;
}

function msgSetStatus(txt) {
    const el = document.getElementById('ap-msg-status');
    if (el) el.textContent = txt;
}

// Monta o texto do aviso. opts.reminder = reaviso (não visualizado); opts.num = nº do aviso
function msgBuildText(count, opts = {}) {
    const plural = count === 1 ? 'mensagem' : 'mensagens';
    const naoLidas = count === 1 ? 'não lida' : 'não lidas';
    const link = 'https://www.99freelas.com.br/messages';
    if (opts.reminder) {
        return `⏰ *LEMBRETE — você ainda não visualizou* (aviso nº ${opts.num})\n\n`
            + `Continua com *${count} ${plural}* ${naoLidas} no 99freelas.\n`
            + `Vou reavisar a cada 5 min até você ler no site.\n\n`
            + `👉 Abrir: ${link}`;
    }
    return `🔔 *NOVA ${plural} no 99freelas*\n\n`
        + `Você tem *${count} ${plural}* ${naoLidas}.\n\n`
        + `👉 Abrir: ${link}`;
}

function msgSendNotification(count, opts = {}) {
    chrome.storage.local.get([AP_MSG_KEYS.group], (r) => {
        const group = r[AP_MSG_KEYS.group];
        if (!group) { msgSetStatus('⚠️ Nenhum grupo selecionado.'); return; }
        const text = msgBuildText(count, opts);
        chrome.runtime.sendMessage({ action: 'evoSendText', to: group, text }, (resp) => {
            if (resp && resp.success) {
                const tipo = opts.reminder ? `Lembrete nº ${opts.num}` : 'Novo aviso';
                msgSetStatus(`🔔 ${tipo} (${count}) às ${new Date().toLocaleTimeString()}`);
            } else {
                msgSetStatus('❌ Falha ao avisar: ' + (resp?.error || 'sem resposta'));
            }
        });
    });
}

function msgCheck() {
    const count = msgGetCount();
    chrome.storage.local.get([AP_MSG_KEYS.lastAt, AP_MSG_KEYS.active, AP_MSG_KEYS.lastCount, AP_MSG_KEYS.num], (r) => {
        const lastAt = r[AP_MSG_KEYS.lastAt] || 0;
        const active = !!r[AP_MSG_KEYS.active];
        const lastCount = r[AP_MSG_KEYS.lastCount] || 0;
        const num = r[AP_MSG_KEYS.num] || 0;
        const now = Date.now();

        if (count > 0) {
            const firstTime = !active;
            const increased = count > lastCount;
            const elapsed = (now - lastAt) >= AP_MSG_RENOTIFY_MS;

            if (firstTime || increased) {
                // Mensagem NOVA (primeiro aviso deste ciclo)
                msgSendNotification(count, { reminder: false, num: 1 });
                chrome.storage.local.set({
                    [AP_MSG_KEYS.lastAt]: now,
                    [AP_MSG_KEYS.active]: true,
                    [AP_MSG_KEYS.lastCount]: count,
                    [AP_MSG_KEYS.num]: 1
                });
            } else if (elapsed) {
                // REAVISO — não visualizou na vez anterior
                const nextNum = num + 1;
                msgSendNotification(count, { reminder: true, num: nextNum });
                chrome.storage.local.set({
                    [AP_MSG_KEYS.lastAt]: now,
                    [AP_MSG_KEYS.active]: true,
                    [AP_MSG_KEYS.lastCount]: count,
                    [AP_MSG_KEYS.num]: nextNum
                });
            } else {
                chrome.storage.local.set({ [AP_MSG_KEYS.lastCount]: count });
            }
        } else {
            // Contador zerou → considerado visualizado no site
            if (active) {
                chrome.storage.local.set({
                    [AP_MSG_KEYS.active]: false,
                    [AP_MSG_KEYS.lastAt]: 0,
                    [AP_MSG_KEYS.lastCount]: 0,
                    [AP_MSG_KEYS.num]: 0
                });
                msgSetStatus('✅ Mensagens visualizadas no site. Avisos pausados.');
            }
        }
    });
}

function startMessageMonitor() {
    stopMessageMonitor();
    msgCheck(); // checagem imediata
    const countEl = document.querySelector('.box-mensagem-count .count-value');
    if (countEl) {
        STATE.msgObserver = new MutationObserver(() => msgCheck());
        STATE.msgObserver.observe(countEl, { childList: true, characterData: true, subtree: true });
    }
    // Fallback: dispara o reaviso de 5 min mesmo sem mudança no DOM
    STATE.msgTimer = setInterval(msgCheck, 60 * 1000);
    msgSetStatus('🔔 Monitor de mensagens ativo.');
}

function stopMessageMonitor() {
    if (STATE.msgObserver) { try { STATE.msgObserver.disconnect(); } catch (e) {} STATE.msgObserver = null; }
    if (STATE.msgTimer) { clearInterval(STATE.msgTimer); STATE.msgTimer = null; }
}

function setupMessageMonitor() {
    if (CURRENT_SITE !== '99freelas') return;
    chrome.storage.local.get([AP_MSG_KEYS.on, AP_MSG_KEYS.group], (r) => {
        if (r[AP_MSG_KEYS.on] && r[AP_MSG_KEYS.group]) startMessageMonitor();
    });
}

function init() {
    injectStyles();
    createSidebar();
    createSettingsModal();
    createToast();
    startQuickBarObserver();

    chrome.storage.local.get([
        'apiKey',
        'groqApiKey',
        'groqModel',
        'openaiKeys',
        'claudeKeys',
        'openaiModel',
        'claudeModel',
        'preferredProvider',
        'activePlatform',
        'userProfile',
        'proposalPrompt',
        'userProfile_99freelas',
        'proposalPrompt_99freelas',
        'userProfile_freelancer',
        'proposalPrompt_freelancer',
        'userProfile_workana',
        'proposalPrompt_workana',
        'shortcuts',
        'autoProposalMode',
        'apiUrl',
        'useBackend',
        'geminiKeys',
        'groqKeys'
    ], (result) => {
        // API Keys & Clusters
        if (result.apiKey) STATE.settings.apiKey = result.apiKey;
        if (result.groqApiKey) STATE.settings.groqApiKey = result.groqApiKey;
        if (result.groqModel) STATE.settings.groqModel = result.groqModel;
        
        if (result.geminiKeys) STATE.settings.geminiKeys = result.geminiKeys;
        if (result.groqKeys) STATE.settings.groqKeys = result.groqKeys;
        if (result.openaiKeys) STATE.settings.openaiKeys = result.openaiKeys;
        if (result.claudeKeys) STATE.settings.claudeKeys = result.claudeKeys;

        // Modelos e Preferências
        if (result.openaiModel) STATE.settings.openaiModel = result.openaiModel;
        if (result.claudeModel) STATE.settings.claudeModel = result.claudeModel;
        if (result.preferredProvider) STATE.settings.preferredProvider = result.preferredProvider;
        if (result.apiUrl) STATE.settings.apiUrl = result.apiUrl;
        if (result.useBackend !== undefined) STATE.settings.useBackend = result.useBackend;

        // Plataforma ativa
        if (result.activePlatform) STATE.settings.activePlatform = result.activePlatform;

        // Prompts (legado + por plataforma)
        if (result.userProfile) STATE.settings.userProfile = result.userProfile;
        if (result.proposalPrompt) STATE.settings.proposalPrompt = result.proposalPrompt;
        if (result.userProfile_99freelas) STATE.settings.userProfile_99freelas = result.userProfile_99freelas;
        if (result.proposalPrompt_99freelas) STATE.settings.proposalPrompt_99freelas = result.proposalPrompt_99freelas;
        if (result.userProfile_freelancer) STATE.settings.userProfile_freelancer = result.userProfile_freelancer;
        if (result.proposalPrompt_freelancer) STATE.settings.proposalPrompt_freelancer = result.proposalPrompt_freelancer;
        if (result.userProfile_workana) STATE.settings.userProfile_workana = result.userProfile_workana;
        if (result.proposalPrompt_workana) STATE.settings.proposalPrompt_workana = result.proposalPrompt_workana;

        // Modo automático
        if (result.autoProposalMode !== undefined) STATE.settings.autoProposalMode = result.autoProposalMode;

        // FIX CRÍTICO: Merge de shortcuts com validação completa
        if (result.shortcuts) {
            STATE.settings.shortcuts = {
                ...STATE.settings.shortcuts, // Padrões
                ...result.shortcuts          // Salvos
            };

            // Garante que 'analyze' exista (caso o storage antigo esteja incompleto)
            if (!STATE.settings.shortcuts.analyze) {
                STATE.settings.shortcuts.analyze = { modifier: 'Shift', key: 'P' };
            }

            // Garante que 'generate' exista
            if (!STATE.settings.shortcuts.generate) {
                STATE.settings.shortcuts.generate = { modifier: 'Shift', key: 'G' };
            }

            // Garante que 'quickSend' exista
            if (!STATE.settings.shortcuts.quickSend) {
                STATE.settings.shortcuts.quickSend = { modifier: 'Shift', key: 'M' };
            }
        }

        console.log('[Auto-Proposal] Settings carregadas:', STATE.settings);
        STATE.settingsLoaded = true;

        // Verifica atualizações
        checkForUpdates();
    });

    // Mouse Hover Edge Detection (com throttle para não pesar)
    let apMouseThrottle = 0;
    document.addEventListener('mousemove', (e) => {
        if (STATE.isSidebarOpen) return;
        const now = Date.now();
        if (now - apMouseThrottle < 100) return;
        apMouseThrottle = now;
        const threshold = 30;
        const isNearEdge = (window.innerWidth - e.clientX) < threshold;
        const handle = document.getElementById('ap-sidebar-handle');

        if (isNearEdge && !STATE.isHoveringEdge) {
            STATE.isHoveringEdge = true;
            handle.classList.add('visible');
        } else if (!isNearEdge && STATE.isHoveringEdge) {
            const rect = handle.getBoundingClientRect();
            const isOverHandle = (e.clientX >= rect.left - 20 && e.clientX <= rect.right + 20 && e.clientY >= rect.top - 20 && e.clientY <= rect.bottom + 20);
            if (!isOverHandle) {
                STATE.isHoveringEdge = false;
                handle.classList.remove('visible');
            }
        }
    }, { passive: true });

    // KEYDOWN HANDLER (Shortcuts)
    document.addEventListener('keydown', (e) => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

        const checkShortcut = (sc) => {
            if (!sc) return false; // Segurança
            let modifierPressed = false;
            if (sc.modifier === 'Shift') modifierPressed = e.shiftKey;
            if (sc.modifier === 'Ctrl') modifierPressed = e.ctrlKey;
            if (sc.modifier === 'Alt') modifierPressed = e.altKey;
            if (sc.modifier === 'Cmd') modifierPressed = e.metaKey;
            return modifierPressed && e.key.toUpperCase() === sc.key.toUpperCase();
        };

        // Usa optional chaining ou fallback
        const scAnalyze = STATE.settings.shortcuts.analyze;
        const scGenerate = STATE.settings.shortcuts.generate;

        if (scAnalyze && checkShortcut(scAnalyze)) {
            e.preventDefault();
            runProjectAnalysis();
        }

        if (scGenerate && checkShortcut(scGenerate)) {
            e.preventDefault();
            runProposalGeneration();
        }

        // Atalho próprio de cada botão de disparo rápido
        if (STATE.quickButtons && STATE.quickButtons.length > 0) {
            const qb = STATE.quickButtons.find(b => b.shortcut && checkShortcut(b.shortcut));
            if (qb) {
                const container = getVisibleSendContainer();
                if (container) {
                    e.preventDefault();
                    triggerQuickButton(qb, container);
                    return;
                }
            }
        }

        // Disparo Rápido (último botão usado, ou o primeiro) — só na página de mensagens
        const scQuick = STATE.settings.shortcuts.quickSend;
        if (scQuick && checkShortcut(scQuick)) {
            const container = getVisibleSendContainer();
            if (container && STATE.quickButtons && STATE.quickButtons.length > 0) {
                e.preventDefault();
                const btn = STATE.quickButtons.find(b => b.id === STATE.lastQuickId) || STATE.quickButtons[0];
                triggerQuickButton(btn, container);
            }
        }
    });

    // URL MONITOR (Auto Mode)
    setInterval(() => {
        if (!STATE.settings.autoProposalMode) return;

        const currentUrl = window.location.href;

        // Detecta página de bid para todos os sites
        const isBidPage99freelas = currentUrl.includes("/project/bid/");
        const isBidPageFreelancer = CURRENT_SITE === 'freelancer' && currentUrl.includes("/projects/");
        const isBidPageWorkana = CURRENT_SITE === 'workana' && currentUrl.includes("/messages/bid/");
        const isBidPage = isBidPage99freelas || isBidPageFreelancer || isBidPageWorkana;

        // Se não estamos na página de bid, limpamos o lastAutoRunUrl
        // Isso garante que se o usuário voltar para a página, o script rode novamente
        if (!isBidPage) {
            STATE.lastAutoRunUrl = '';
            return;
        }

        // Se estamos na página de bid E ainda não rodamos para esta URL específica
        if (isBidPage && STATE.lastAutoRunUrl !== currentUrl) {

            // FIX IMPORTANTE: Verifica se o formulário já existe no DOM
            // Evita rodar em página de "Loading..." ou antes do render completo
            let formIsReady = false;

            if (CURRENT_SITE === 'freelancer') {
                // Para Freelancer.com, espera o componente app-bid-form carregar completamente
                // O elemento 'descriptionTextArea' dentro de app-bid-form indica que o form está pronto
                const bidForm = document.querySelector('app-bid-form');
                const descriptionTextArea = document.getElementById('descriptionTextArea');
                formIsReady = bidForm && descriptionTextArea;

                if (bidForm && !descriptionTextArea) {
                    console.log("[Auto-Proposal] Freelancer: app-bid-form encontrado, aguardando descriptionTextArea...");
                }
            } else if (CURRENT_SITE === 'workana') {
                // Para Workana, verifica o campo BidContent
                const proposalForm = document.getElementById('BidContent');
                formIsReady = !!proposalForm;
            } else {
                // Para 99freelas, verifica o campo proposta
                const proposalForm = document.getElementById('proposta');
                formIsReady = !!proposalForm;
            }

            if (formIsReady) {
                STATE.lastAutoRunUrl = currentUrl;
                console.log("[Auto-Proposal] Página de Proposta detectada e carregada. Iniciando modo automático...");
                console.log("[Auto-Proposal] NOTA: A proposta será preenchida mas NÃO será enviada automaticamente.");
                showToast("🤖 Modo Auto: Gerando proposta...", "loading");
                runProposalGeneration();
            }
        }
    }, 1000); // Intervalo de checagem mais rápido (1s)

    // RADAR (Auto-Bid): handler da aba de bid + wiring + auto-start
    setupRadar();

    // MONITOR DE MENSAGENS: avisa no WhatsApp quando houver mensagens novas
    setupMessageMonitor();
}

function getUserPhotoUrl(email) {
    const photos = {
        'patrick@gmail.com': chrome.runtime.getURL('patrick.png'),
        'beatrizmello@gmail.com': chrome.runtime.getURL('beatriz.png'),
        'patricksiqueira.developer@gmail.com': chrome.runtime.getURL('patrick.png')
    };
    return photos[email] || null;
}

function openProfile() {
    const sidebar = document.getElementById('ap-sidebar');
    let contentContainer = document.getElementById('ap-sidebar-content');
    if (!contentContainer) {
        contentContainer = document.createElement('div');
        contentContainer.id = 'ap-sidebar-content';
        contentContainer.style.height = '100%';
        sidebar.appendChild(contentContainer);
    }
    contentContainer.innerHTML = '';

    const userPhotoUrl = getUserPhotoUrl(STATE.user.email);
    const avatarHtml = userPhotoUrl 
        ? `<img src="${userPhotoUrl}" alt="" class="ap-profile-avatar">` 
        : `<div class="ap-profile-avatar-fallback">${STATE.user.name.split(' ').map(n=>n[0]).join('').substring(0,2)}</div>`;

    const profileContainer = document.createElement('div');
    profileContainer.className = 'ap-profile-screen';
    profileContainer.innerHTML = `
        <div class="ap-profile-header">
            <button id="ap-profile-back" class="ap-profile-back">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
            </button>
            <h2 style="font-size: 18px; font-weight: 700; margin: 0;">Meu Perfil</h2>
        </div>

        ${avatarHtml}
        <div class="ap-profile-name">${STATE.user.name}</div>
        <div class="ap-profile-email">${STATE.user.email}</div>

        <div class="ap-profile-section-title">Segurança</div>
        <form id="ap-profile-form" class="ap-profile-form">
            <div class="ap-login-input-group">
                <label class="ap-login-label">Nova Senha</label>
                <input type="password" id="ap-profile-password" class="ap-login-input" placeholder="••••••••" required>
            </div>
            <div id="ap-profile-msg" class="ap-profile-msg"></div>
            <button type="submit" id="ap-profile-save" class="ap-profile-save">Salvar Alterações</button>
        </form>
    `;
    contentContainer.appendChild(profileContainer);

    document.getElementById('ap-profile-back').addEventListener('click', (e) => { e.stopPropagation(); renderSidebarContent(); });
    document.getElementById('ap-profile-form').addEventListener('submit', handleUpdateProfile);
    
    // Impede que cliques no formulário fechem a sidebar
    profileContainer.addEventListener('click', (e) => e.stopPropagation());
}

async function handleUpdateProfile(e) {
    e.preventDefault();
    const password = document.getElementById('ap-profile-password').value;
    const btn = document.getElementById('ap-profile-save');
    const msg = document.getElementById('ap-profile-msg');

    btn.disabled = true;
    btn.innerText = 'Salvando...';
    msg.className = 'ap-profile-msg';

    try {
        const response = await fetch(`${STATE.settings.apiUrl}/api/auth/update`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                id: STATE.user.id,
                name: STATE.user.name,
                email: STATE.user.email,
                password 
            })
        });

        const data = await response.json();

        if (data.success) {
            msg.innerText = 'Perfil atualizado com sucesso!';
            msg.classList.add('success');
            STATE.user.password = password;
            chrome.storage.local.set({ 'ap_user': STATE.user });
            setTimeout(renderSidebarContent, 1500);
        } else {
            msg.innerText = data.error || 'Erro ao atualizar.';
            msg.classList.add('error');
        }
    } catch (err) {
        msg.innerText = 'Erro ao conectar com a API.';
        msg.classList.add('error');
    } finally {
        btn.disabled = false;
        btn.innerText = 'Salvar Alterações';
    }
}

async function checkForUpdates() {
    try {
        const response = await fetch('https://geral-auto-proposal-dashboard.r954jc.easypanel.host/version.json');
        const data = await response.json();
        const currentVersion = "1.0.1";

        if (data.version > currentVersion) {
            const sidebar = document.getElementById('ap-sidebar');
            const updateBanner = document.createElement('div');
            updateBanner.style.cssText = `
                background: var(--ap-accent-gradient);
                color: white;
                padding: 10px;
                font-size: 12px;
                text-align: center;
                cursor: pointer;
                font-weight: 700;
                animation: ap-fadeInUp 0.5s ease-out;
                border-radius: 0 0 12px 12px;
                box-shadow: 0 4px 15px rgba(10,132,255,0.3);
            `;
            updateBanner.innerHTML = `🚀 Nova Versão ${data.version} disponível! Clique para baixar.`;
            updateBanner.onclick = () => window.open(data.downloadUrl, '_blank');
            
            const header = document.querySelector('.ap-header');
            if (header) {
                header.parentNode.insertBefore(updateBanner, header.nextSibling);
            }
        }
    } catch (err) {
        console.error('[Auto-Proposal] Erro ao verificar atualizações:', err);
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}